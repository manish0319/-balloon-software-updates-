import tkinter as tk
from tkinter import filedialog, messagebox, colorchooser, ttk, simpledialog
from PIL import Image, ImageDraw, ImageFont, ImageTk, ImageEnhance, ImageFilter
import PyPDF2
from datetime import date, datetime
import win32api
import win32print
from pdf2image import convert_from_path
import math
import json
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import tempfile
import shutil
import pyperclip
from PIL import ImageGrab
import csv
import requests
import threading
import time
import zipfile
import io
import sys
import subprocess

class RotationDialog(tk.Toplevel):
    def __init__(self, parent, initial_angle=0):
        super().__init__(parent)
        self.title("Pin Rotation")
        self.geometry("300x150")
        
        # Make dialog modal
        self.transient(parent)
        self.grab_set()
        
        # Rotation angle
        self.angle = tk.DoubleVar(value=initial_angle)
        
        # Create widgets
        tk.Label(self, text="Rotation Angle (degrees):").pack(pady=10)
        
        # Slider for rotation
        self.slider = tk.Scale(self, from_=0, to=360, orient=tk.HORIZONTAL, 
                             variable=self.angle, command=self.on_slide)
        self.slider.pack(fill=tk.X, padx=20)
        
        # Buttons
        btn_frame = tk.Frame(self)
        btn_frame.pack(pady=20)
        
        tk.Button(btn_frame, text="OK", command=self.ok).pack(side=tk.LEFT, padx=10)
        tk.Button(btn_frame, text="Cancel", command=self.cancel).pack(side=tk.LEFT)
        
        self.result = None
        
    def on_slide(self, value):
        self.angle.set(float(value))
        
    def ok(self):
        self.result = self.angle.get()
        self.destroy()
        
    def cancel(self):
        self.destroy()

class UpdateManager:
    def __init__(self, app):
        self.app = app
        self.current_version = "1.0.0"  # Current version of the software
        self.update_url = "https://your-update-server.com/updates"  # Replace with your update server URL
        self.update_check_interval = 3600  # Check for updates every hour (in seconds)
        self.last_check = 0
        
    def check_for_updates(self, force=False):
        """Check for available updates"""
        current_time = time.time()
        if not force and current_time - self.last_check < self.update_check_interval:
            return
            
        try:
            response = requests.get(f"{self.update_url}/version.json")
            if response.status_code == 200:
                latest_version = response.json().get("version")
                if latest_version and latest_version > self.current_version:
                    self.notify_update_available(latest_version)
            self.last_check = current_time
        except Exception as e:
            print(f"Error checking for updates: {e}")
            
    def notify_update_available(self, new_version):
        """Show update notification to user"""
        result = messagebox.askyesno(
            "Update Available",
            f"A new version ({new_version}) is available. Would you like to update now?"
        )
        if result:
            self.download_and_apply_update()
            
    def download_and_apply_update(self):
        """Download and apply the update"""
        try:
            # Show progress dialog
            progress = tk.Toplevel(self.app.master)
            progress.title("Updating...")
            progress.geometry("300x100")
            progress_label = tk.Label(progress, text="Downloading update...")
            progress_label.pack(pady=20)
            progress_bar = ttk.Progressbar(progress, length=200, mode='indeterminate')
            progress_bar.pack(pady=10)
            progress_bar.start()
            
            # Download update package
            response = requests.get(f"{self.update_url}/update.zip")
            if response.status_code == 200:
                # Extract update
                with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
                    zip_ref.extractall("temp_update")
                
                # Close the application
                self.app.master.destroy()
                
                # Launch updater
                updater_script = os.path.join("temp_update", "updater.py")
                subprocess.Popen([sys.executable, updater_script])
                
        except Exception as e:
            messagebox.showerror("Update Error", f"Failed to apply update: {e}")
            if 'progress' in locals():
                progress.destroy()

class BubbleAndStampApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Bubble and Stamp App")
        self.master.geometry("1200x800")
        
        # Initialize update manager
        self.update_manager = UpdateManager(self)
        
        # Start update check in background
        self.start_update_check()
        
        # Default properties
        self.bubble_size = 25
        self.bubble_color = "blue"
        self.bubble_number = 1
        self.stamp_size = 10
        self.stamp_color = "red"
        self.image = None
        self.original_image = None
        self.canvas_image = None
        self.add_stamp_mode = False
        self.current_stamp = "MYPL"
        self.drawn_elements = []
        self.bubble_style = "pin"  # Default bubble style
        self.bubble_fill = False  # Default no fill
        self.rotating_pin = None
        self.rotation_angle = 0
        self.rotation_start = None
        self.rotation_angles = {}  # Add this to store rotation angles for pins
        self.recent_files = []  # Add list to store recent files
        
        # Email settings
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        self.email_settings = self.load_email_settings()
        self.saved_emails = self.load_saved_emails()
        self.saved_cc_emails = self.load_saved_cc_emails()
        self.saved_bcc_emails = self.load_saved_bcc_emails()
        self.email_history = self.load_email_history()

        # Create a left frame for controls
        control_frame = tk.Frame(self.master, padx=5, pady=5, relief=tk.RAISED, borderwidth=2)
        control_frame.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)

        # Create a canvas for the control frame with reduced size
        control_canvas = tk.Canvas(control_frame, width=200, height=600)
        control_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Add a scrollbar to the control frame with reduced height
        scrollbar = tk.Scrollbar(self.master, orient="vertical", command=control_canvas.yview)
        scrollbar.pack(side=tk.LEFT, fill=tk.Y, expand=False)

        # Create a frame inside the canvas to hold the buttons
        button_frame = tk.Frame(control_canvas)

        # Configure the canvas
        control_canvas.create_window((0, 0), window=button_frame, anchor="nw")
        control_canvas.configure(yscrollcommand=scrollbar.set)

        # Add F1 Help button at the top
        help_frame = tk.Frame(button_frame, relief=tk.RAISED, borderwidth=1)
        help_frame.pack(fill=tk.X, pady=5)
        help_button = tk.Button(help_frame, text="F1 Help", command=self.show_help, bg='lightblue')
        help_button.pack(fill=tk.X, padx=5, pady=5)
        
        # Bind F1 key to help
        self.master.bind('<F1>', lambda e: self.show_help())

        # Update the scroll region when the frame size changes
        def on_frame_configure(event):
            control_canvas.configure(scrollregion=control_canvas.bbox("all"))

        button_frame.bind("<Configure>", on_frame_configure)

        # Replace control_frame with button_frame for button creation
        self.create_button(button_frame, "Upload File", self.upload_file)
        self.create_button(button_frame, "Save", self.save_drawing)
        self.create_button(button_frame, "Print", self.print_drawing)

        # Bubble settings
        bubble_frame = tk.LabelFrame(button_frame, text="Bubble Settings", padx=5, pady=5)
        bubble_frame.pack(fill=tk.X, pady=10)

        tk.Label(bubble_frame, text="Bubble Size:").pack(anchor="w")
        self.bubble_size_entry = tk.Entry(bubble_frame, width=10)
        self.bubble_size_entry.insert(0, str(self.bubble_size))
        self.bubble_size_entry.pack(fill=tk.X)

        tk.Label(bubble_frame, text="Custom Number:").pack(anchor="w")
        self.custom_bubble_number_entry = tk.Entry(bubble_frame, width=10)
        self.custom_bubble_number_entry.pack(fill=tk.X)

        self.create_button(bubble_frame, "Set Bubble Number", self.set_bubble_number)
        self.create_button(bubble_frame, "Set Bubble Size", self.set_bubble_size)
        self.create_button(bubble_frame, "Select Bubble Color", self.choose_bubble_color)

        # Bubble style settings
        bubble_style_frame = tk.LabelFrame(bubble_frame, text="Bubble Style", padx=5, pady=5)
        bubble_style_frame.pack(fill=tk.X, pady=5)

        # Bubble style dropdown
        self.bubble_style_var = tk.StringVar(value="pin")
        bubble_styles = ["circle", "square", "diamond", "hexagon", "star", "pin"]
        style_dropdown = ttk.Combobox(bubble_style_frame, textvariable=self.bubble_style_var, values=bubble_styles)
        style_dropdown.pack(fill=tk.X, pady=2)

        # Fill checkbox
        self.fill_var = tk.BooleanVar(value=False)
        fill_check = tk.Checkbutton(bubble_style_frame, text="Fill Bubble", variable=self.fill_var)
        fill_check.pack(anchor="w")

        # Stamp settings
        stamp_frame = tk.LabelFrame(button_frame, text="Stamp Settings", padx=5, pady=5)
        stamp_frame.pack(fill=tk.X, pady=10)

        tk.Label(stamp_frame, text="Size:").pack(anchor="w")
        self.stamp_size_entry = tk.Entry(stamp_frame, width=10)
        self.stamp_size_entry.insert(0, str(self.stamp_size))
        self.stamp_size_entry.pack(fill=tk.X)

        self.create_button(stamp_frame, "Set Stamp Size", self.set_stamp_size)
        self.create_button(stamp_frame, "Select Stamp Color", self.choose_stamp_color)

        # Custom Stamp Entry
        tk.Label(stamp_frame, text="Custom Stamp Text:").pack(anchor="w", pady=(10,0))
        self.custom_stamp_entry = tk.Entry(stamp_frame)
        self.custom_stamp_entry.pack(fill=tk.X, pady=5)
        self.create_button(stamp_frame, "Add Custom Stamp", lambda: self.set_stamp("CUSTOM"))

        # Buttons for adding stamps
        self.create_button(stamp_frame, "Add MYPL Stamp", lambda: self.set_stamp("MYPL"))
        self.create_button(stamp_frame, "Add NPD Stamp", lambda: self.set_stamp("NPD"))

        # Undo and Reset buttons
        self.create_button(button_frame, "Undo", self.undo_last_action)
        self.create_button(button_frame, "Reset", self.reset_canvas)

        # Add the Contact Us button
        self.create_button(button_frame, "Contact Us", self.contact_us)

        # Add Email buttons
        email_frame = tk.LabelFrame(button_frame, text="Email Options", padx=5, pady=5)
        email_frame.pack(fill=tk.X, pady=10)
        self.create_button(email_frame, "Configure Email", self.configure_email)
        self.create_button(email_frame, "Send via Email", self.send_email)

        # Create a canvas for drawing
        canvas_frame = tk.Frame(self.master)
        canvas_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Add scrollbars
        h_scrollbar = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL)
        v_scrollbar = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Create the canvas with scrollbars
        self.canvas = tk.Canvas(canvas_frame, width=1200, height=900, bg="white",
                              xscrollcommand=h_scrollbar.set,
                              yscrollcommand=v_scrollbar.set)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Configure scrollbars
        h_scrollbar.config(command=self.canvas.xview)
        v_scrollbar.config(command=self.canvas.yview)

        # Configure canvas scrolling region
        self.canvas.config(scrollregion=(0, 0, 2000, 2000))  # Initial scroll region

        # Bind mouse wheel events for scrolling
        self.canvas.bind('<MouseWheel>', self._on_mousewheel)  # Windows
        self.canvas.bind('<Button-4>', self._on_mousewheel)    # Linux scroll up
        self.canvas.bind('<Button-5>', self._on_mousewheel)    # Linux scroll down

        # Bind mouse click event to draw bubbles or stamps based on the mode
        self.canvas.bind("<Button-1>", self.handle_click)

        # Add these lines after creating the canvas
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)

        self.setup_shortcuts()

        # Add after the other buttons in button_frame
        template_frame = tk.LabelFrame(button_frame, text="Templates", padx=5, pady=5)
        template_frame.pack(fill=tk.X, pady=10)
        
        self.create_button(template_frame, "Save as Template", self.save_drawing_with_template)
        self.create_button(template_frame, "Load Template", self.load_and_apply_template)
        self.create_button(template_frame, "Delete Template", self.delete_template)

        # Add Suggest Improvement button
        suggest_button = tk.Button(help_frame, text="Suggest Improvement", 
                                 command=self.suggest_improvement, 
                                 bg='#FF9800', fg='white')
        suggest_button.pack(fill=tk.X, padx=5, pady=5)

        # Create floating chatbot icon
        self.create_floating_chatbot()

    def create_floating_chatbot(self):
        """Create a floating chatbot icon in the bottom-right corner"""
        icon_size = 48
        padding = 20
        
        # Create main frame
        chat_icon = tk.Frame(self.master, bg='#2196F3', width=icon_size, height=icon_size)
        chat_icon.place(relx=1, rely=1, x=-(icon_size + padding), y=-(icon_size + padding))
        chat_icon.pack_propagate(False)
        
        # Create canvas
        canvas = tk.Canvas(chat_icon, width=icon_size, height=icon_size, 
                         bg='#2196F3', highlightthickness=0)
        canvas.pack(fill=tk.BOTH, expand=True)
        
        # Draw main circle
        circle = canvas.create_oval(4, 4, icon_size-4, icon_size-4, 
                                 fill='#2196F3', outline='white', width=2)
        
        # Create modern message bubble design
        bubble_width = 24
        bubble_height = 16
        center_x = icon_size / 2
        center_y = icon_size / 2
        
        # Message bubble coordinates
        left = center_x - bubble_width/2
        right = center_x + bubble_width/2
        top = center_y - bubble_height/2
        bottom = center_y + bubble_height/2
        
        # Create message bubble with tail
        bubble_points = [
            left, top,                       # Top left
            right, top,                      # Top right
            right, bottom,                   # Bottom right
            center_x + 4, bottom,            # Start of tail
            center_x + 8, bottom + 6,        # Tail point
            center_x, bottom,                # End of tail
            left, bottom,                    # Bottom left
        ]
        
        # Draw bubble
        bubble = canvas.create_polygon(bubble_points, 
                                     fill='white', 
                                     outline='white',
                                     smooth=True,
                                     width=2)
        
        # Add animated dots
        dot_y = center_y
        dot_radius = 2
        dots = []
        for i, x_offset in enumerate([-8, 0, 8]):
            dot = canvas.create_oval(
                center_x + x_offset - dot_radius, dot_y - dot_radius,
                center_x + x_offset + dot_radius, dot_y + dot_radius,
                fill='#2196F3', outline='#2196F3'
            )
            dots.append(dot)
        
        # Animate dots
        def animate_dots():
            for i, dot in enumerate(dots):
                # Create bounce animation
                delay = i * 150  # Stagger the animations
                
                def bounce_dot(dot=dot):
                    original_coords = canvas.coords(dot)
                    
                    # Bounce up
                    for y in range(5):
                        canvas.move(dot, 0, -0.8)
                        canvas.update()
                        canvas.after(20)
                    
                    # Bounce down
                    for y in range(5):
                        canvas.move(dot, 0, 0.8)
                        canvas.update()
                        canvas.after(20)
                
                canvas.after(delay, bounce_dot)
            
            # Repeat animation
            canvas.after(2000, animate_dots)
        
        # Start dot animation
        animate_dots()
        
        # Hover effect
        def on_enter(e):
            canvas.configure(bg='#1976D2')
            canvas.itemconfig(circle, fill='#1976D2')
            canvas.itemconfig(bubble, fill='white', outline='white')
            for dot in dots:
                canvas.itemconfig(dot, fill='#1976D2', outline='#1976D2')
            
            # Show tooltip
            tooltip.place(relx=1, rely=1, 
                        x=-(icon_size + padding + tooltip.winfo_reqwidth() + 10),
                        y=-(icon_size + padding + 5))
        
        def on_leave(e):
            canvas.configure(bg='#2196F3')
            canvas.itemconfig(circle, fill='#2196F3')
            canvas.itemconfig(bubble, fill='white', outline='white')
            for dot in dots:
                canvas.itemconfig(dot, fill='#2196F3', outline='#2196F3')
            tooltip.place_forget()
        
        # Click effect
        def on_click(e):
            canvas.configure(bg='#1565C0')
            canvas.itemconfig(circle, fill='#1565C0')
            canvas.itemconfig(bubble, fill='white', outline='white')
            for dot in dots:
                canvas.itemconfig(dot, fill='#1565C0', outline='#1565C0')
            
            # Add ripple effect
            ripple = canvas.create_oval(
                icon_size/2-5, icon_size/2-5,
                icon_size/2+5, icon_size/2+5,
                fill='white', stipple='gray50'
            )
            
            def remove_ripple():
                canvas.delete(ripple)
                self.show_chatbot()
            
            self.master.after(150, remove_ripple)
        
        def on_release(e):
            canvas.configure(bg='#1976D2')
            canvas.itemconfig(circle, fill='#1976D2')
            canvas.itemconfig(bubble, fill='white', outline='white')
            for dot in dots:
                canvas.itemconfig(dot, fill='#1976D2', outline='#1976D2')
        
        # Create tooltip
        tooltip = tk.Label(self.master, text="Chat Assistant",
                         bg='#424242', fg='white',
                         padx=8, pady=4,
                         font=('Segoe UI', 9))
        
        # Bind events
        canvas.bind('<Enter>', on_enter)
        canvas.bind('<Leave>', on_leave)
        canvas.bind('<Button-1>', on_click)
        canvas.bind('<ButtonRelease-1>', on_release)

    def setup_shortcuts(self):
        """Setup keyboard shortcuts"""
        # File operations
        self.master.bind('<Control-z>', lambda e: self.undo_last_action())
        self.master.bind('<Control-s>', lambda e: self.save_drawing())
        self.master.bind('<Control-o>', lambda e: self.upload_file())
        self.master.bind('<Control-p>', lambda e: self.print_drawing())
        
        # Edit operations
        self.master.bind('<Delete>', lambda e: self.delete_selected())
        self.master.bind('<Control-a>', lambda e: self.select_all())
        
        # View operations
        self.master.bind('<Control-g>', lambda e: self.toggle_grid())
        
        # Make sure focus is set to handle keyboard events
        self.master.focus_set()

    def create_button(self, parent, text, command):
        # Create outer frame for 3D shadow effect
        outer_frame = tk.Frame(parent, bg='#1565C0')  # Dark blue shadow
        outer_frame.pack(fill=tk.X, pady=2, padx=2)
        
        # Create main button frame with 3D effect
        btn_frame = tk.Frame(outer_frame, relief=tk.RAISED, borderwidth=1)
        btn_frame.pack(fill=tk.X, padx=1, pady=1)  # Small offset for shadow
        
        # Create the button with modern, compact styling
        button = tk.Button(btn_frame, text=text, command=command,
                          font=('Segoe UI', 8),
                          bg='#2196F3',
                          fg='white',
                          relief=tk.RAISED,
                          borderwidth=0,
                          padx=5,
                          pady=2,
                          cursor='hand2',
                          width=15)
        button.pack(fill=tk.X, expand=True)
        
        # Animation state
        animation_state = {'pressed': False, 'hover': False}
        
        def animate_press():
            if animation_state['pressed']:
                # Move button and shadow for pressed effect
                outer_frame.pack_configure(padx=1, pady=1)
                btn_frame.pack_configure(padx=2, pady=2)
                button['background'] = '#1565C0'
                
                # Create ripple effect
                ripple = tk.Canvas(button, width=20, height=20, highlightthickness=0, bg='white')
                ripple.place(relx=0.5, rely=0.5, anchor='center')
                ripple.create_oval(0, 0, 20, 20, fill='#90CAF9', outline='')
                
                def fade_ripple():
                    ripple.destroy()
                button.after(150, fade_ripple)
            
            button.after(10, animate_press if animation_state['pressed'] else animate_release)
        
        def animate_release():
            if not animation_state['pressed']:
                # Restore original position
                outer_frame.pack_configure(padx=2, pady=2)
                btn_frame.pack_configure(padx=1, pady=1)
                button['background'] = '#1976D2' if animation_state['hover'] else '#2196F3'
        
        def on_enter(e):
            animation_state['hover'] = True
            button['background'] = '#1976D2'
            btn_frame.config(relief=tk.RAISED)
            
            # Add glow effect
            outer_frame.config(bg='#90CAF9')
            button.after(100, lambda: outer_frame.config(bg='#1565C0'))
        
        def on_leave(e):
            animation_state['hover'] = False
            button['background'] = '#2196F3'
            btn_frame.config(relief=tk.RAISED)
            outer_frame.config(bg='#1565C0')
        
        def on_click(e):
            animation_state['pressed'] = True
            animate_press()
        
        def on_release(e):
            animation_state['pressed'] = False
            animate_release()

        # Bind mouse events
        button.bind("<Enter>", on_enter)
        button.bind("<Leave>", on_leave)
        button.bind("<Button-1>", on_click)
        button.bind("<ButtonRelease-1>", on_release)

        return button

    def create_special_button(self, parent, text, command, color='#2196F3', icon=None):
        """Create a special button with enhanced 3D effects and animations"""
        # Create outer frame for 3D shadow
        outer_frame = tk.Frame(parent, bg=self._adjust_color(color, -40))
        outer_frame.pack(fill=tk.X, pady=2, padx=2)
        
        # Create main button frame
        btn_frame = tk.Frame(outer_frame, relief=tk.RAISED, borderwidth=1)
        btn_frame.pack(fill=tk.X, padx=1, pady=1)
        
        # Create gradient canvas
        canvas = tk.Canvas(btn_frame, height=25, highlightthickness=0)
        canvas.pack(fill=tk.X)
        
        # Create gradient effect
        canvas.create_rectangle(0, 0, 500, 25, fill=color, outline='', tags='bg')
        
        # Add highlight line for 3D effect
        canvas.create_line(0, 0, 500, 0, fill='#FFFFFF', width=1, stipple='gray50')
        
        # Add text with shadow
        shadow_offset = 1
        canvas.create_text(251, 13, text=text, fill='#000000', font=('Segoe UI', 8), state='disabled')
        text_id = canvas.create_text(250, 12, text=text, fill='white', font=('Segoe UI', 8))
        
        # Animation state
        animation_state = {'pressed': False}
        
        def animate_press():
            if animation_state['pressed']:
                # Move button down
                btn_frame.pack_configure(padx=2, pady=2)
                canvas.itemconfig('bg', fill=self._adjust_color(color, -40))
                
                # Move text for pressed effect
                canvas.coords(text_id, 251, 13)
                
                # Add ripple effect
                ripple_id = canvas.create_oval(240, 10, 260, 30, fill='#FFFFFF', stipple='gray25')
                def remove_ripple():
                    canvas.delete(ripple_id)
                canvas.after(150, remove_ripple)
            
            canvas.after(10, animate_press if animation_state['pressed'] else animate_release)
        
        def animate_release():
            if not animation_state['pressed']:
                btn_frame.pack_configure(padx=1, pady=1)
                canvas.itemconfig('bg', fill=color)
                canvas.coords(text_id, 250, 12)
        
        def on_enter(e):
            canvas.itemconfig('bg', fill=self._adjust_color(color, -20))
            outer_frame.config(bg=self._adjust_color(color, -20))
            
            # Add glow effect
            glow = canvas.create_rectangle(0, 0, 500, 25, fill='#FFFFFF', stipple='gray25')
            canvas.after(100, lambda: canvas.delete(glow))
        
        def on_leave(e):
            canvas.itemconfig('bg', fill=color)
            outer_frame.config(bg=self._adjust_color(color, -40))
        
        def on_click(e):
            animation_state['pressed'] = True
            animate_press()
            if command: command()
        
        def on_release(e):
            animation_state['pressed'] = False
            animate_release()

        # Bind events
        canvas.bind("<Enter>", on_enter)
        canvas.bind("<Leave>", on_leave)
        canvas.bind("<Button-1>", on_click)
        canvas.bind("<ButtonRelease-1>", on_release)
        
        return canvas

    def _adjust_color(self, color, amount):
        """Adjust hex color brightness"""
        if color.startswith('#'):
            color = color[1:]
        rgb = tuple(int(color[i:i+2], 16) for i in (0, 2, 4))
        rgb = tuple(min(max(x + amount, 0), 255) for x in rgb)
        return '#{:02x}{:02x}{:02x}'.format(*rgb)

    def create_category_header(self, parent, text):
        """Create a styled category header with 3D effects"""
        # Create outer frame for 3D shadow
        outer_frame = tk.Frame(parent, bg='#0D47A1')
        outer_frame.pack(fill=tk.X, pady=(5,2), padx=2)
        
        # Create main header frame
        header_frame = tk.Frame(outer_frame, relief=tk.RAISED, borderwidth=1)
        header_frame.pack(fill=tk.X, padx=1, pady=1)
        
        # Create canvas for gradient effect
        canvas = tk.Canvas(header_frame, height=20, highlightthickness=0)
        canvas.pack(fill=tk.X)
        
        # Create gradient background
        canvas.create_rectangle(0, 0, 500, 20, fill='#1976D2', outline='')
        
        # Add highlight line for 3D effect
        canvas.create_line(0, 0, 500, 0, fill='#FFFFFF', width=1, stipple='gray50')
        
        # Add text with shadow
        canvas.create_text(251, 11, text=text, fill='#000000', font=('Segoe UI', 8, 'bold'), state='disabled')
        canvas.create_text(250, 10, text=text, fill='white', font=('Segoe UI', 8, 'bold'))
        
        def on_enter(e):
            canvas.itemconfig(1, fill='#1565C0')
            outer_frame.config(bg='#1565C0')
        
        def on_leave(e):
            canvas.itemconfig(1, fill='#1976D2')
            outer_frame.config(bg='#0D47A1')
        
        # Bind hover effects
        canvas.bind("<Enter>", on_enter)
        canvas.bind("<Leave>", on_leave)
        
        return header_frame

    def set_bubble_number(self):
        """Update the bubble number based on user input."""
        try:
            custom_number = int(self.custom_bubble_number_entry.get())
            if custom_number > 0:
                self.bubble_number = custom_number
            else:
                raise ValueError("Number must be greater than zero.")
        except ValueError:
            tk.messagebox.showerror("Invalid Input", "Please enter a valid positive integer for the bubble number.")

    def upload_file(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("Image files", "*.jpeg;*.jpg;*.png"), ("PDF files", "*.pdf")]
        )
        
        if file_path:  # Check if a file was selected
            if file_path.lower().endswith(('.jpeg', '.jpg', '.png')):
                try:
                    # Handle image upload
                    self.original_image = Image.open(file_path)
                    if self.original_image.mode != 'RGB':
                        self.original_image = self.original_image.convert('RGB')  # Ensure RGB mode
                    
                    # Get original image dimensions
                    img_width, img_height = self.original_image.size
                    
                    # Resize while maintaining aspect ratio
                    self.original_image = self.original_image.resize((1200, 900), Image.Resampling.LANCZOS)
                    sharpness_enhancer = ImageEnhance.Sharpness(self.original_image)
                    self.original_image = sharpness_enhancer.enhance(1.5)
                    contrast_enhancer = ImageEnhance.Contrast(self.original_image)
                    self.original_image = contrast_enhancer.enhance(1.2)
                    brightness_enhancer = ImageEnhance.Brightness(self.original_image)
                    self.original_image = brightness_enhancer.enhance(1.1)

                    img = self.original_image.copy()
                    self.image = ImageTk.PhotoImage(img)
                    if self.canvas_image:
                        self.canvas.delete(self.canvas_image)
                    self.canvas_image = self.canvas.create_image(0, 0, anchor="nw", image=self.image)
                    
                    # Update canvas scroll region to match image size
                    self.canvas.config(scrollregion=(0, 0, max(1200, img_width), max(900, img_height)))
                    
                    messagebox.showinfo("Image Upload", f"Image file '{file_path}' uploaded successfully!")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to open image: {e}")
            
            elif file_path.lower().endswith('.pdf'):
                try:
                    # Handle PDF upload by converting the first page to an image
                    try:
                        pages = convert_from_path(file_path, dpi=300)
                    except Exception as e:
                        if "poppler" in str(e).lower():
                            messagebox.showerror("Poppler Error", 
                                "Poppler is required to handle PDF files. Please follow these steps:\n\n"
                                "1. Download Poppler for Windows from: https://github.com/oschwartz10612/poppler-windows/releases/\n"
                                "2. Extract the downloaded ZIP file\n"
                                "3. Add the extracted 'poppler-xx\\Library\\bin' path to your system's PATH environment variable\n"
                                "4. Restart the application\n\n"
                                "For detailed instructions, visit: https://pdf2image.readthedocs.io/en/latest/installation.html")
                            return
                        else:
                            raise e

                    if pages:
                        self.original_image = pages[0]  # Take the first page
                        enhancer = ImageEnhance.Sharpness(self.original_image)
                        self.original_image = enhancer.enhance(2.0)
                        img = self.original_image.copy()
                        img.thumbnail((1200, 900))
                        self.image = ImageTk.PhotoImage(img)
                        if self.canvas_image:
                            self.canvas.delete(self.canvas_image)
                        self.canvas_image = self.canvas.create_image(0, 0, anchor="nw", image=self.image)
                        messagebox.showinfo("PDF Upload", f"PDF file '{file_path}' uploaded and displaying the first page.")
                except Exception as e:
                    if "poppler" not in str(e).lower():
                        messagebox.showerror("Error", f"Failed to open PDF: {e}")
        
        elif file_path.lower().endswith('.pdf'):
            try:
                # Convert the first page of the PDF to an image
                pages = convert_from_path(file_path, dpi=150, first_page=1, last_page=1)
                self.original_image = pages[0]  # Use the first page for display
                
                img = self.original_image.copy()
                img.thumbnail((1200, 900))  # Resize for canvas display
                self.image = ImageTk.PhotoImage(img)
                self.canvas_image = self.canvas.create_image(0, 0, anchor="nw", image=self.image)
                
                messagebox.showinfo("PDF Upload", f"PDF file '{file_path}' uploaded successfully!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open PDF: {e}")

    def set_bubble_size(self):
        try:
            self.bubble_size = int(self.bubble_size_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid integer for bubble size.")
    
    def choose_bubble_color(self):
        color = colorchooser.askcolor()[1]  # Returns a tuple (RGB, Hex)
        if color:
            self.bubble_color = color
    
    def set_stamp_size(self):
        try:
            self.stamp_size = int(self.stamp_size_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid integer for stamp size.")
    
    def choose_stamp_color(self):
        color = colorchooser.askcolor()[1]  # Returns a tuple (RGB, Hex)
        if color:
            self.stamp_color = color

    def set_stamp(self, stamp_type):
        self.current_stamp = stamp_type
        self.add_stamp_mode = True
        messagebox.showinfo("Stamp Mode", f"Click anywhere to place the '{self.current_stamp}' stamp.")

    def handle_click(self, event):
        """Modified handle_click to include selection functionality"""
        # Convert window coordinates to canvas coordinates
        canvas_event = self.create_event_with_canvas_coords(event)
        
        if event.state & 0x1:  # Check if Shift key is pressed
            self.select_bubble(canvas_event)
        elif event.state & 0x4:  # Check if Control key is pressed
            self.edit_bubble(canvas_event)
        else:
            if self.add_stamp_mode:
                self.place_stamp(canvas_event)
            else:
                if self.bubble_style_var.get() == "pin":
                    self.draw_directional_pin(canvas_event)
                else:
                    self.draw_bubble(canvas_event)

    def select_bubble(self, event):
        """Select a bubble when clicked with Shift key"""
        x, y = event.x, event.y
        
        for element in self.drawn_elements:
            if element[0] == "bubble":
                _, bubble_ids, text_id, bx, by, size, color, number, style, fill = element[:10]
                radius = size / 2
                
                # Check if click is within bubble bounds
                if (bx - radius <= x <= bx + radius and 
                    by - radius <= y <= by + radius):
                    # Toggle selection
                    if isinstance(bubble_ids, list):  # For pins
                        current_fill = self.canvas.itemcget(bubble_ids[0], 'fill')
                        new_fill = 'lightblue' if current_fill != 'lightblue' else (color if fill else '')
                        for bid in bubble_ids:
                            self.canvas.itemconfig(bid, fill=new_fill)
                    else:  # For other shapes
                        current_fill = self.canvas.itemcget(bubble_ids, 'fill')
                        new_fill = 'lightblue' if current_fill != 'lightblue' else (color if fill else '')
                        self.canvas.itemconfig(bubble_ids, fill=new_fill)
                    break

    def delete_selected(self, event=None):
        """Delete selected bubbles"""
        selected = []
        for i, element in enumerate(self.drawn_elements):
            if element[0] == "bubble":
                _, bubble_ids, text_id, x, y, size, color, number, style, fill = element[:10]
                # Check if any part of the bubble is selected
                if isinstance(bubble_ids, list):  # For pins
                    for bid in bubble_ids:
                        if self.canvas.itemcget(bid, 'fill') == 'lightblue':  # Selection color
                            selected.append(i)
                            break
                else:  # For other shapes
                    if self.canvas.itemcget(bubble_ids, 'fill') == 'lightblue':  # Selection color
                        selected.append(i)
        
        # Remove selected elements in reverse order
        for index in reversed(selected):
            element = self.drawn_elements[index]
            if element[0] == "bubble":
                _, bubble_ids, text_id, *_ = element
                if isinstance(bubble_ids, list):
                    for bid in bubble_ids:
                        self.canvas.delete(bid)
                else:
                    self.canvas.delete(bubble_ids)
                self.canvas.delete(text_id)
            self.drawn_elements.pop(index)

    def enhance_image(self, image):
        """
        Enhances the quality of the image by applying filters.
        """
        try:
            image = image.filter(ImageFilter.SHARPEN)  # Apply sharpening
            enhancer = ImageEnhance.Contrast(image)
            image = enhancer.enhance(1.2)  # Increase contrast slightly
            return image
        except Exception as e:
            messagebox.showerror("Enhancement Error", f"Failed to enhance image: {e}")
            return image  # Return the original image if enhancement fails


    def draw_bubble(self, event):
        x, y = event.x, event.y
        radius = self.bubble_size / 2
        
        custom_number = self.custom_bubble_number_entry.get().strip() if hasattr(self, 'custom_bubble_number_entry') else None
        if custom_number and custom_number.isdigit():
            bubble_number = int(custom_number)
            self.custom_bubble_number_entry.delete(0, tk.END)
        else:
            bubble_number = self.bubble_number

        style = self.bubble_style_var.get()
        fill = self.fill_var.get()
        fill_color = self.bubble_color if fill else ""

        if style == "pin":
            # Create the circle (top part) - moved up more
            circle_id = self.canvas.create_oval(
                x - radius, y - radius - radius,  # Moved up by full radius instead of radius/2
                x + radius, y + radius - radius,
                outline=self.bubble_color, fill=fill_color, width=2
            )
            
            # Create the triangle (bottom part) - made longer
            triangle_points = [
                x - radius/2, y + radius - radius,  # Left point
                x + radius/2, y + radius - radius,  # Right point
                x, y + radius * 2  # Bottom point made longer (1.5 -> 2)
            ]
            triangle_id = self.canvas.create_polygon(
                triangle_points,
                outline=self.bubble_color,
                fill=self.bubble_color,  # Always fill the tail
                width=2
            )
            
            # Group both shapes as one bubble
            bubble_id = [circle_id, triangle_id]
            
            # Adjust text position for the new pin height
            text_y = y - radius  # Adjusted to match new circle position
            text_id = self.canvas.create_text(x, text_y, text=str(bubble_number), fill="black")
            self.drawn_elements.append(("bubble", bubble_id, text_id, x, y, self.bubble_size, 
                                      self.bubble_color, bubble_number, style, fill))
        else:
            if style == "circle":
                bubble_id = self.canvas.create_oval(
                    x - radius, y - radius, x + radius, y + radius,
                    outline=self.bubble_color, fill=fill_color, width=2
                )
            elif style == "square":
                bubble_id = self.canvas.create_rectangle(
                    x - radius, y - radius, x + radius, y + radius,
                    outline=self.bubble_color, fill=fill_color, width=2
                )
            elif style == "diamond":
                points = [
                    (x, y - radius),
                    (x + radius, y),
                    (x, y + radius),
                    (x - radius, y)
                ]
                bubble_id = self.canvas.create_polygon(
                    points, outline=self.bubble_color, fill=fill_color,
                    width=2, smooth=False
                )
            elif style == "hexagon":
                r = radius
                points = [
                    (x - r/2, y - r),
                    (x + r/2, y - r),
                    (x + r, y),
                    (x + r/2, y + r),
                    (x - r/2, y + r),
                    (x - r, y)
                ]
                bubble_id = self.canvas.create_polygon(
                    points, outline=self.bubble_color, fill=fill_color,
                    width=2, smooth=False
                )
            elif style == "star":
                points = self._calculate_star_points(x, y, radius)
                bubble_id = self.canvas.create_polygon(
                    points, outline=self.bubble_color, fill=fill_color,
                    width=2, smooth=False
                )
            
            # Add text and store in drawn_elements for all other shapes
            text_id = self.canvas.create_text(x, y, text=str(bubble_number), fill="black")
            self.drawn_elements.append(("bubble", bubble_id, text_id, x, y, self.bubble_size, 
                                      self.bubble_color, bubble_number, style, fill))

        self.bubble_number += 1

    def _calculate_star_points(self, cx, cy, r):
        points = []
        for i in range(10):  # 5 points star has 10 vertices
            angle = i * math.pi / 5 - math.pi / 2
            r_use = r if i % 2 == 0 else r/2
            x = cx + r_use * math.cos(angle)
            y = cy + r_use * math.sin(angle)
            points.extend([x, y])
        return points

    def place_stamp(self, event):
        x, y = event.x, event.y
        today_date = date.today().strftime("%d-%m-%Y")
        
        stamp_ids = []
        if self.current_stamp == "MYPL":
            stamp_ids.append(self.canvas.create_text(x, y, text="MYPL", fill=self.stamp_color, font=("Arial", self.stamp_size)))
            stamp_ids.append(self.canvas.create_text(x, y + self.stamp_size + 5, text="CONTROLLED,IF RED", fill=self.stamp_color, font=("Arial", self.stamp_size)))
            stamp_ids.append(self.canvas.create_text(x, y + (self.stamp_size + 5) * 2, text=f"ISSUE DATE: {today_date}", fill=self.stamp_color, font=("Arial", self.stamp_size)))
            stamp_ids.append(self.canvas.create_text(x, y + (self.stamp_size + 5) * 3, text="by Mjoshi", fill=self.stamp_color, font=("Arial", self.stamp_size)))
        elif self.current_stamp == "NPD":
            stamp_ids.append(self.canvas.create_text(x, y, text="NPD", fill=self.stamp_color, font=("Arial", self.stamp_size)))
        elif self.current_stamp == "CUSTOM":
            custom_text = self.custom_stamp_entry.get().strip()
            if custom_text:
                stamp_ids.append(self.canvas.create_text(x, y, text=custom_text, fill=self.stamp_color, font=("Arial", self.stamp_size)))
                self.custom_stamp_entry.delete(0, tk.END)  # Clear the entry after placing stamp
            else:
                messagebox.showwarning("Empty Text", "Please enter text for the custom stamp.")
                self.add_stamp_mode = False
                return
        
        self.drawn_elements.append(("stamp", stamp_ids))  
        self.add_stamp_mode = False

    def undo_last_action(self):
        if self.drawn_elements:
            last_element = self.drawn_elements.pop()
            if last_element[0] == "bubble":
                _, bubble_id, text_id, _, _, _, _, _, style, _ = last_element[:10]  # Get only first 10 elements
                
                # Handle pin shape
                if style == "pin":
                    if isinstance(bubble_id, list):
                        for id in bubble_id:
                            self.canvas.delete(id)
                    # Remove from rotation angles if it exists
                    if bubble_id[0] in self.rotation_angles:
                        del self.rotation_angles[bubble_id[0]]
                else:
                    # Handle other shapes
                    self.canvas.delete(bubble_id)
                
                # Delete the text for all shapes
                self.canvas.delete(text_id)
                
                # Decrement bubble number
                if self.bubble_number > 1:
                    self.bubble_number -= 1
                
            elif last_element[0] == "stamp":
                _, stamp_ids = last_element
                for stamp_id in stamp_ids:
                    self.canvas.delete(stamp_id)

    def reset_canvas(self):
        self.canvas.delete("all")
        self.bubble_number = 1
        self.drawn_elements = []

    def contact_us(self):
         messagebox.showinfo("Contact Us", "Name: Manish Vijay\nMobile No: +917062040094")   

    def suggest_improvement(self):
        """Enhanced suggestion system with categories, screenshots, and tracking"""
        suggestion_window = tk.Toplevel(self.master)
        suggestion_window.title("Suggest Improvement")
        suggestion_window.geometry("800x800")
        suggestion_window.transient(self.master)
        suggestion_window.grab_set()

        # Create main frame with scrollbar
        main_frame = tk.Frame(suggestion_window)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # Add canvas for scrolling
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Category selection
        category_frame = tk.LabelFrame(scrollable_frame, text="Category", padx=10, pady=10)
        category_frame.pack(fill=tk.X, pady=(0, 20))

        category_var = tk.StringVar(value="UI/UX")
        categories = ["UI/UX", "Performance", "Features", "Bugs", "Documentation", "Other"]
        
        for category in categories:
            tk.Radiobutton(category_frame, text=category, variable=category_var, 
                          value=category).pack(anchor=tk.W)

        # Priority selection
        priority_frame = tk.LabelFrame(scrollable_frame, text="Priority", padx=10, pady=10)
        priority_frame.pack(fill=tk.X, pady=(0, 20))

        priority_var = tk.StringVar(value="Medium")
        priorities = ["Low", "Medium", "High", "Critical"]
        
        for priority in priorities:
            tk.Radiobutton(priority_frame, text=priority, variable=priority_var, 
                          value=priority).pack(anchor=tk.W)

        # Title
        title_frame = tk.LabelFrame(scrollable_frame, text="Title", padx=10, pady=10)
        title_frame.pack(fill=tk.X, pady=(0, 20))
        
        title_entry = tk.Entry(title_frame, width=70)
        title_entry.pack(fill=tk.X, padx=5, pady=5)

        # Description
        desc_frame = tk.LabelFrame(scrollable_frame, text="Description", padx=10, pady=10)
        desc_frame.pack(fill=tk.X, pady=(0, 20))
        
        desc_text = tk.Text(desc_frame, height=10, width=70)
        desc_text.pack(fill=tk.X, padx=5, pady=5)

        # Screenshot functionality
        screenshot_frame = tk.LabelFrame(scrollable_frame, text="Screenshots", padx=10, pady=10)
        screenshot_frame.pack(fill=tk.X, pady=(0, 20))

        screenshot_paths = []
        screenshot_labels = []

        def attach_screenshot():
            file_paths = filedialog.askopenfilenames(
                title="Select Screenshots",
                filetypes=[("Image files", "*.png *.jpg *.jpeg *.gif *.bmp")]
            )
            
            for file_path in file_paths:
                try:
                    # Copy file to temp directory
                    temp_dir = tempfile.mkdtemp()
                    new_path = os.path.join(temp_dir, os.path.basename(file_path))
                    shutil.copy2(file_path, new_path)
                    screenshot_paths.append(new_path)
                    
                    # Create and display thumbnail
                    img = Image.open(new_path)
                    thumbnail = img.copy()
                    thumbnail.thumbnail((100, 100))
                    photo = ImageTk.PhotoImage(thumbnail)
                    
                    # Create label with delete button
                    thumb_frame = tk.Frame(screenshot_frame)
                    thumb_frame.pack(side=tk.LEFT, padx=5, pady=5)
                    
                    label = tk.Label(thumb_frame, image=photo)
                    label.image = photo
                    label.pack()
                    
                    def delete_screenshot(path=new_path, frame=thumb_frame):
                        frame.destroy()
                        if path in screenshot_paths:
                            screenshot_paths.remove(path)
                            try:
                                os.remove(path)
                                os.rmdir(os.path.dirname(path))
                            except:
                                pass
                    
                    delete_btn = tk.Button(thumb_frame, text="×", command=delete_screenshot,
                                         bg='red', fg='white', font=('Segoe UI', 8, 'bold'))
                    delete_btn.pack()
                    
                    screenshot_labels.append(thumb_frame)
                    
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to attach screenshot: {e}")

        screenshot_buttons = tk.Frame(screenshot_frame)
        screenshot_buttons.pack(fill=tk.X, pady=5)
        
        tk.Button(screenshot_buttons, text="Attach Screenshots", 
                 command=attach_screenshot,
                 bg='#2196F3', fg='white', 
                 font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=5)

        def submit_suggestion():
            # Validate inputs
            title = title_entry.get().strip()
            description = desc_text.get("1.0", tk.END).strip()
            
            if not title or not description:
                messagebox.showerror("Error", "Title and description are required")
                return

            try:
                # Create suggestion data
                suggestion_data = {
                    'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    'category': category_var.get(),
                    'priority': priority_var.get(),
                    'title': title,
                    'description': description,
                    'status': 'Pending',
                    'screenshots': []
                }
                
                # Create suggestions directory if it doesn't exist
                suggestions_dir = "suggestions"
                if not os.path.exists(suggestions_dir):
                    os.makedirs(suggestions_dir)
                
                # Create suggestion-specific directory
                suggestion_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                suggestion_dir = os.path.join(suggestions_dir, f"suggestion_{suggestion_timestamp}")
                os.makedirs(suggestion_dir)
                
                # Save screenshots
                for i, screenshot_path in enumerate(screenshot_paths):
                    if os.path.exists(screenshot_path):
                        new_path = os.path.join(suggestion_dir, f"screenshot_{i+1}.png")
                        shutil.copy2(screenshot_path, new_path)
                        suggestion_data['screenshots'].append(f"screenshot_{i+1}.png")
                
                # Save suggestion data
                with open(os.path.join(suggestion_dir, "suggestion.json"), 'w') as f:
                    json.dump(suggestion_data, f, indent=4)
                
                # Clean up temporary files
                for path in screenshot_paths:
                    try:
                        os.remove(path)
                        os.rmdir(os.path.dirname(path))
                    except:
                        pass
                
                messagebox.showinfo("Success", 
                    "Thank you for your suggestion! Your feedback helps us improve the application.")
                suggestion_window.destroy()

            except Exception as e:
                messagebox.showerror("Error", f"Failed to submit suggestion: {e}")

        def view_suggestions():
            self.show_suggestions_history()

        # Buttons
        button_frame = tk.Frame(scrollable_frame)
        button_frame.pack(pady=20)

        tk.Button(button_frame, text="Submit", command=submit_suggestion,
                 bg='#4CAF50', fg='white', font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="View Previous Suggestions", command=view_suggestions,
                 bg='#2196F3', fg='white', font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Cancel", command=suggestion_window.destroy,
                 bg='#f44336', fg='white', font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=5)

        # Pack the canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Configure mouse wheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def show_suggestions_history(self):
        """Show history of submitted suggestions with enhanced functionality"""
        history_window = tk.Toplevel(self.master)
        history_window.title("Suggestion History")
        history_window.geometry("1200x800")
        history_window.transient(self.master)
        history_window.grab_set()

        # Create main frame
        main_frame = tk.Frame(history_window)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Create search and filter frame
        filter_frame = tk.LabelFrame(main_frame, text="Search & Filters", padx=10, pady=5)
        filter_frame.pack(fill=tk.X, pady=(0, 10))

        # Search
        search_frame = tk.Frame(filter_frame)
        search_frame.pack(fill=tk.X, pady=5)
        tk.Label(search_frame, text="Search:").pack(side=tk.LEFT, padx=5)
        search_entry = tk.Entry(search_frame, width=40)
        search_entry.pack(side=tk.LEFT, padx=5)

        # Filters
        filter_options_frame = tk.Frame(filter_frame)
        filter_options_frame.pack(fill=tk.X, pady=5)

        # Category filter
        tk.Label(filter_options_frame, text="Category:").pack(side=tk.LEFT, padx=5)
        category_var = tk.StringVar(value="All")
        category_filter = ttk.Combobox(filter_options_frame, textvariable=category_var, 
                                     values=["All", "UI/UX", "Performance", "Features", "Bugs", "Documentation", "Other"])
        category_filter.pack(side=tk.LEFT, padx=5)

        # Priority filter
        tk.Label(filter_options_frame, text="Priority:").pack(side=tk.LEFT, padx=5)
        priority_var = tk.StringVar(value="All")
        priority_filter = ttk.Combobox(filter_options_frame, textvariable=priority_var,
                                     values=["All", "Low", "Medium", "High", "Critical"])
        priority_filter.pack(side=tk.LEFT, padx=5)

        # Status filter
        tk.Label(filter_options_frame, text="Status:").pack(side=tk.LEFT, padx=5)
        status_var = tk.StringVar(value="All")
        status_filter = ttk.Combobox(filter_options_frame, textvariable=status_var,
                                   values=["All", "Pending", "In Progress", "Completed", "Rejected"])
        status_filter.pack(side=tk.LEFT, padx=5)

        # Date range filter
        date_frame = tk.Frame(filter_frame)
        date_frame.pack(fill=tk.X, pady=5)
        tk.Label(date_frame, text="Date From:").pack(side=tk.LEFT, padx=5)
        date_from = tk.Entry(date_frame, width=12)
        date_from.pack(side=tk.LEFT, padx=5)
        tk.Label(date_frame, text="To:").pack(side=tk.LEFT, padx=5)
        date_to = tk.Entry(date_frame, width=12)
        date_to.pack(side=tk.LEFT, padx=5)

        # Create treeview with scrollbar
        tree_frame = tk.Frame(main_frame)
        tree_frame.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        columns = ("Date", "Category", "Priority", "Title", "Status")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings", yscrollcommand=scrollbar.set)
        tree.pack(fill=tk.BOTH, expand=True)

        scrollbar.config(command=tree.yview)

        # Configure columns
        for col in columns:
            tree.heading(col, text=col, command=lambda c=col: self.sort_treeview(tree, c, False))
            tree.column(col, width=150)

        def load_suggestions(search_text="", category="All", priority="All", status="All", 
                           date_from_val="", date_to_val=""):
            # Clear existing items
            for item in tree.get_children():
                tree.delete(item)

            suggestions_dir = "suggestions"
            if os.path.exists(suggestions_dir):
                for suggestion_folder in os.listdir(suggestions_dir):
                    folder_path = os.path.join(suggestions_dir, suggestion_folder)
                    if os.path.isdir(folder_path):
                        json_path = os.path.join(folder_path, "suggestion.json")
                        if os.path.exists(json_path):
                            with open(json_path, 'r') as f:
                                suggestion = json.load(f)
                                
                                # Apply filters
                                if search_text and not any(search_text.lower() in str(v).lower() 
                                                         for v in suggestion.values()):
                                    continue
                                if category != "All" and suggestion['category'] != category:
                                    continue
                                if priority != "All" and suggestion['priority'] != priority:
                                    continue
                                if status != "All" and suggestion['status'] != status:
                                    continue
                                
                                # Date filter
                                if date_from_val or date_to_val:
                                    suggestion_date = datetime.strptime(suggestion['date'].split()[0], 
                                                                      '%Y-%m-%d')
                                    if date_from_val:
                                        try:
                                            from_date = datetime.strptime(date_from_val, '%Y-%m-%d')
                                            if suggestion_date < from_date:
                                                continue
                                        except ValueError:
                                            pass
                                    if date_to_val:
                                        try:
                                            to_date = datetime.strptime(date_to_val, '%Y-%m-%d')
                                            if suggestion_date > to_date:
                                                continue
                                        except ValueError:
                                            pass
                                
                                tree.insert("", "end", values=(
                                    suggestion['date'],
                                    suggestion['category'],
                                    suggestion['priority'],
                                    suggestion['title'],
                                    suggestion['status']
                                ), tags=(folder_path,))

        def apply_filters(*args):
            load_suggestions(
                search_text=search_entry.get(),
                category=category_var.get(),
                priority=priority_var.get(),
                status=status_var.get(),
                date_from_val=date_from.get(),
                date_to_val=date_to.get()
            )

        # Bind filter changes
        search_entry.bind('<KeyRelease>', apply_filters)
        category_filter.bind('<<ComboboxSelected>>', apply_filters)
        priority_filter.bind('<<ComboboxSelected>>', apply_filters)
        status_filter.bind('<<ComboboxSelected>>', apply_filters)
        date_from.bind('<KeyRelease>', apply_filters)
        date_to.bind('<KeyRelease>', apply_filters)

        def update_status():
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showwarning("No Selection", "Please select a suggestion to update")
                return

            folder_path = tree.item(selected_item[0], 'tags')[0]
            json_path = os.path.join(folder_path, "suggestion.json")
            
            if os.path.exists(json_path):
                # Create status update dialog
                status_dialog = tk.Toplevel(history_window)
                status_dialog.title("Update Status")
                status_dialog.geometry("300x200")
                status_dialog.transient(history_window)
                status_dialog.grab_set()

                tk.Label(status_dialog, text="New Status:").pack(pady=10)
                status_var = tk.StringVar(value="Pending")
                status_combo = ttk.Combobox(status_dialog, textvariable=status_var,
                                          values=["Pending", "In Progress", "Completed", "Rejected"])
                status_combo.pack(pady=5)

                tk.Label(status_dialog, text="Comment:").pack(pady=5)
                comment_text = tk.Text(status_dialog, height=3, width=30)
                comment_text.pack(pady=5)

                def save_status():
                    with open(json_path, 'r') as f:
                        suggestion = json.load(f)
                    
                    suggestion['status'] = status_var.get()
                    suggestion['status_comment'] = comment_text.get("1.0", tk.END).strip()
                    suggestion['status_updated'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    with open(json_path, 'w') as f:
                        json.dump(suggestion, f, indent=4)
                    
                    status_dialog.destroy()
                    apply_filters()  # Refresh the list

                tk.Button(status_dialog, text="Save", command=save_status,
                         bg='#4CAF50', fg='white', font=('Segoe UI', 9, 'bold')).pack(pady=10)

        def export_suggestions():
            file_path = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV files", "*.csv"), ("Excel files", "*.xlsx")]
            )
            
            if file_path:
                try:
                    if file_path.endswith('.csv'):
                        with open(file_path, 'w', newline='') as csvfile:
                            writer = csv.writer(csvfile)
                            # Write headers
                            writer.writerow(["Date", "Category", "Priority", "Title", "Status", 
                                           "Description", "Last Updated"])
                            
                            # Write data
                            for item in tree.get_children():
                                folder_path = tree.item(item, 'tags')[0]
                                json_path = os.path.join(folder_path, "suggestion.json")
                                if os.path.exists(json_path):
                                    with open(json_path, 'r') as f:
                                        suggestion = json.load(f)
                                        writer.writerow([
                                            suggestion['date'],
                                            suggestion['category'],
                                            suggestion['priority'],
                                            suggestion['title'],
                                            suggestion['status'],
                                            suggestion['description'],
                                            suggestion.get('status_updated', '')
                                        ])
                    else:  # Excel export
                        import pandas as pd
                        data = []
                        for item in tree.get_children():
                            folder_path = tree.item(item, 'tags')[0]
                            json_path = os.path.join(folder_path, "suggestion.json")
                            if os.path.exists(json_path):
                                with open(json_path, 'r') as f:
                                    suggestion = json.load(f)
                                    data.append({
                                        'Date': suggestion['date'],
                                        'Category': suggestion['category'],
                                        'Priority': suggestion['priority'],
                                        'Title': suggestion['title'],
                                        'Status': suggestion['status'],
                                        'Description': suggestion['description'],
                                        'Last Updated': suggestion.get('status_updated', '')
                                    })
                        df = pd.DataFrame(data)
                        df.to_excel(file_path, index=False)
                    
                    messagebox.showinfo("Success", "Suggestions exported successfully!")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to export suggestions: {e}")

        # Add buttons frame
        button_frame = tk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=10)

        tk.Button(button_frame, text="Update Status", command=update_status,
                 bg='#2196F3', fg='white', font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Export", command=export_suggestions,
                 bg='#4CAF50', fg='white', font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Close", command=history_window.destroy,
                 bg='#f44336', fg='white', font=('Segoe UI', 9, 'bold')).pack(side=tk.RIGHT, padx=5)

        # Initial load
        load_suggestions()

        def sort_treeview(tree, col, reverse):
            """Sort treeview by column"""
            l = [(tree.set(k, col), k) for k in tree.get_children('')]
            l.sort(reverse=reverse)

            # Rearrange items in sorted positions
            for index, (val, k) in enumerate(l):
                tree.move(k, '', index)

            # Reverse sort next time
            tree.heading(col, command=lambda: sort_treeview(tree, col, not reverse))

        # Load initial data
        load_suggestions()

    def save_drawing(self):
        """Save the drawing to a file."""
        # Get the initial directory
        initial_dir = os.path.expanduser("~/Documents")
        
        # Ask for save location with PDF as default
        file_path = filedialog.asksaveasfilename(
            initialdir=initial_dir,
            title="Save Drawing",
            defaultextension=".pdf",  # Changed from .png to .pdf
            filetypes=[
                ("PDF files", "*.pdf"),  # Made PDF the first option
                ("PNG files", "*.png"),
                ("JPEG files", "*.jpg"),
                ("All files", "*.*")
            ]
        )
        
        if file_path:
            try:
                # Get file extension
                _, ext = os.path.splitext(file_path)
                ext = ext.lower()
                
                if ext == '.pdf':
                    self.save_as_pdf(file_path)
                else:
                    self.save_drawing_to_file(file_path)
                    
                # Add to recent files
                self.add_recent_file(file_path)
                
                messagebox.showinfo("Success", "Drawing saved successfully!")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save drawing: {str(e)}")

    def print_drawing(self):
        if self.original_image:
            # Create a new image to draw on for printing
            img = Image.new("RGB", (804, 624), "white")
            draw = ImageDraw.Draw(img)
            img.paste(self.original_image.resize((804, 624)), (0, 0))

            # Draw all elements stored in drawn_elements for printing
            for element in self.drawn_elements:
                if element[0] == "bubble":
                    _, bubble_id, text_id, x, y, size, color, number, style, fill = element
                    radius = size / 2
                    fill_color = color if fill else None

                    if style == "pin":
                        # Draw circle part - adjusted position
                        draw.ellipse(
                            [x - radius, y - radius - radius,
                             x + radius, y + radius - radius],
                            outline=color, fill=fill_color, width=2
                        )
                        # Draw triangle part - made longer
                        draw.polygon([
                            (x - radius/2, y + radius - radius),
                            (x + radius/2, y + radius - radius),
                            (x, y + radius * 2)
                        ], outline=color, fill=color)
                        
                        # Adjust text position
                        text_y = y - radius
                        font = ImageFont.truetype("arial.ttf", self.stamp_size)
                        text_bbox = draw.textbbox((0, 0), str(number), font=font)
                        text_width = text_bbox[2] - text_bbox[0]
                        text_x = x - text_width / 2
                        draw.text((text_x, text_y - self.stamp_size/2), str(number), fill="black", font=font)
                    else:
                        if style == "circle":
                            draw.ellipse([x - radius, y - radius, x + radius, y + radius],
                                       outline=color, fill=fill_color, width=2)
                        elif style == "square":
                            draw.rectangle([x - radius, y - radius, x + radius, y + radius],
                                         outline=color, fill=fill_color, width=2)
                        elif style == "diamond":
                            points = [
                                (x, y - radius),
                                (x + radius, y),
                                (x, y + radius),
                                (x - radius, y)
                            ]
                            draw.polygon(points, outline=color, fill=fill_color)
                        elif style == "hexagon":
                            r = radius
                            points = [
                                (x - r/2, y - r),
                                (x + r/2, y - r),
                                (x + r, y),
                                (x + r/2, y + r),
                                (x - r/2, y + r),
                                (x - r, y)
                            ]
                            draw.polygon(points, outline=color, fill=fill_color)
                        elif style == "star":
                            points = self._calculate_star_points(x, y, radius)
                            point_pairs = [(points[i], points[i+1]) for i in range(0, len(points), 2)]
                            draw.polygon(point_pairs, outline=color, fill=fill_color)

                        font = ImageFont.truetype("arial.ttf", self.stamp_size)
                        text_size = draw.textlength(str(number), font=font)
                        text_x = x - text_size / 2
                        text_y = y - self.stamp_size / 2
                        draw.text((text_x, text_y), str(number), fill="black", font=font)

                elif element[0] == "stamp":
                    _, stamp_ids = element
                    x, y = self.canvas.coords(stamp_ids[0])
                    if "MYPL" in self.canvas.itemcget(stamp_ids[0], 'text'):
                        draw.text((x, y), "MYPL", fill=self.stamp_color, font=ImageFont.truetype("arial.ttf", self.stamp_size))
                        draw.text((x, y + self.stamp_size + 5), "CONTROLLED,IF RED", fill=self.stamp_color, font=ImageFont.truetype("arial.ttf", self.stamp_size))
                        draw.text((x, y + (self.stamp_size + 5) * 2), f"ISSUE DATE: {date.today().strftime('%d-%m-%Y')}", fill=self.stamp_color, font=ImageFont.truetype("arial.ttf", self.stamp_size))
                        draw.text((x, y + (self.stamp_size + 5) * 3), "by Mjoshi", fill=self.stamp_color, font=ImageFont.truetype("arial.ttf", self.stamp_size))
                    elif "NPD" in self.canvas.itemcget(stamp_ids[0], 'text'):
                        draw.text((x, y), "NPD", fill=self.stamp_color, font=ImageFont.truetype("arial.ttf", self.stamp_size))
                    elif "CUSTOM" in self.canvas.itemcget(stamp_ids[0], 'text'):
                        draw.text((x, y), self.canvas.itemcget(stamp_ids[0], 'text'), fill=self.stamp_color, font=ImageFont.truetype("arial.ttf", self.stamp_size))
                        
            # Save to a temporary file for printing
            temp_file = "temp_print_image.jpg"
            img.save(temp_file, quality=95)  # Save with high quality
            win32api.ShellExecute(0, "print", temp_file, None, ".", 0)  # Send to printer
            messagebox.showinfo("Print", "The image has been sent to the printer.")
        else:
            messagebox.showerror("Print Error", "No image available for printing.")

    def start_rotation(self, event):
        """Start pin rotation when clicked on a pin bubble"""
        x, y = event.x, event.y
        # Check if we clicked on a pin
        for element in self.drawn_elements:
            if element[0] == "bubble" and element[8] == "pin":
                _, bubble_ids, text_id, center_x, center_y, size, color, number, style, fill = element
                # Calculate if click is within pin bounds
                radius = size / 2
                if (center_x - radius <= x <= center_x + radius and 
                    center_y - 2*radius <= y <= center_y + 2*radius):
                    self.rotating_pin = element
                    self.rotation_start = (x, y)
                    # Bind motion and release events
                    self.canvas.bind("<B1-Motion>", self.rotate_pin)
                    self.canvas.bind("<ButtonRelease-1>", self.end_rotation)
                    break

    def rotate_pin(self, event):
        """Handle pin rotation while dragging"""
        if self.rotating_pin and self.rotation_start:
            _, bubble_ids, text_id, center_x, center_y, size, color, number, style, fill = self.rotating_pin
            
            # Calculate angle between start point and current point
            start_angle = math.atan2(self.rotation_start[1] - center_y, 
                                   self.rotation_start[0] - center_x)
            current_angle = math.atan2(event.y - center_y, event.x - center_x)
            angle = math.degrees(current_angle - start_angle)
            
            # Update rotation
            self.rotation_angle = angle
            self.redraw_rotated_pin(self.rotating_pin)
            self.rotation_start = (event.x, event.y)

    def end_rotation(self, event):
        """End pin rotation"""
        self.rotating_pin = None
        self.rotation_start = None
        self.canvas.unbind("<B1-Motion>")
        self.canvas.unbind("<ButtonRelease-1>")

    def redraw_rotated_pin(self, pin_element):
        _, bubble_ids, text_id, x, y, size, color, number, style, fill = pin_element
        radius = size / 2
        
        # Delete existing pin elements
        for id in bubble_ids:
            self.canvas.delete(id)
        self.canvas.delete(text_id)
        
        # Draw circle part
        circle_id = self.canvas.create_oval(
            x - radius, y - radius - radius,
            x + radius, y + radius - radius,
            outline=color, fill=color if fill else "", width=2
        )
        
        # Calculate rotated triangle points
        angle_rad = math.radians(self.rotation_angle)
        triangle_base = [(x - radius/2, y + radius - radius),
                        (x + radius/2, y + radius - radius),
                        (x, y + radius * 2)]
        
        # Rotate points around center
        rotated_points = []
        for px, py in triangle_base:
            dx = px - x
            dy = py - y
            rx = dx * math.cos(angle_rad) - dy * math.sin(angle_rad)
            ry = dx * math.sin(angle_rad) + dy * math.cos(angle_rad)
            rotated_points.extend([x + rx, y + ry])
        
        # Draw rotated triangle
        triangle_id = self.canvas.create_polygon(
            rotated_points,
            outline=color,
            fill=color,
            width=2
        )
        
        # Add text
        text_y = y - radius
        text_id = self.canvas.create_text(x, text_y, text=str(number), fill="black")
        
        # Update the drawn elements list
        pin_element[1] = [circle_id, triangle_id]
        pin_element[2] = text_id

    def draw_directional_pin(self, event):
        if not hasattr(self, 'pin_start'):
            self.pin_start = (event.x, event.y)
            self.temp_pin = None
        else:
            end_x, end_y = event.x, event.y
            start_x, start_y = self.pin_start
            
            # Calculate angle from start to end point
            angle = math.degrees(math.atan2(end_y - start_y, end_x - start_x)) - 90
            
            radius = self.bubble_size / 2
            fill_color = self.bubble_color if self.fill_var.get() else ""
            
            # Create circle part
            circle_id = self.canvas.create_oval(
                start_x - radius, start_y - radius,
                start_x + radius, start_y + radius,
                outline=self.bubble_color, fill=fill_color, width=2
            )
            
            # Create triangle with rotation
            triangle_id = self.create_rotated_triangle(start_x, start_y, radius, angle)
            
            text_id = self.canvas.create_text(
                start_x, start_y, 
                text=str(self.bubble_number),
                fill="black"
            )
            
            # Store the pin with its rotation angle
            self.drawn_elements.append((
                "bubble",
                [circle_id, triangle_id],
                text_id,
                start_x, start_y,
                self.bubble_size,
                self.bubble_color,
                self.bubble_number,
                "pin",
                self.fill_var.get(),
                angle  # Store the original angle
            ))
            
            # Store the angle
            self.rotation_angles[circle_id] = angle
            
            self.bubble_number += 1
            delattr(self, 'pin_start')
            if self.temp_pin:
                for item in self.temp_pin:
                    self.canvas.delete(item)
                self.temp_pin = None

    def create_rotated_triangle(self, x, y, radius, angle):
        """Create a rotated triangle for the pin"""
        angle_rad = math.radians(angle)
        
        # Increase triangle size proportions - made longer
        triangle_base = [
            (x - radius/1.2, y + radius),      # Left point - wider
            (x + radius/1.2, y + radius),      # Right point - wider
            (x, y + radius * 3.5)              # Bottom point - much longer
        ]
        
        # Rotate points around the center (x, y)
        rotated_points = []
        for px, py in triangle_base:
            # Translate point to origin
            dx = px - x
            dy = py - y
            # Rotate
            rx = dx * math.cos(angle_rad) - dy * math.sin(angle_rad)
            ry = dx * math.sin(angle_rad) + dy * math.cos(angle_rad)
            # Translate back
            rotated_points.extend([x + rx, y + ry])
        
        return self.canvas.create_polygon(
            rotated_points,
            outline=self.bubble_color,
            fill=self.bubble_color,
            width=2
        )

    def update_temp_pin(self, event):
        """Update the temporary pin preview while dragging"""
        if hasattr(self, 'pin_start'):
            start_x, start_y = self.pin_start
            end_x, end_y = event.x, event.y
            
            # Calculate angle
            angle = math.degrees(math.atan2(end_y - start_y, end_x - start_x)) - 90
            
            # Delete previous temporary pin if it exists
            if self.temp_pin:
                for item in self.temp_pin:
                    self.canvas.delete(item)
            
            # Draw temporary pin
            radius = self.bubble_size / 2
            fill_color = self.bubble_color if self.fill_var.get() else ""
            
            # Create temporary circle
            temp_circle = self.canvas.create_oval(
                start_x - radius, start_y - radius,
                start_x + radius, start_y + radius,
                outline=self.bubble_color, fill=fill_color, width=2
            )
            
            # Calculate and create temporary triangle with larger proportions
            angle_rad = math.radians(angle)
            triangle_base = [
                (start_x - radius/1.2, start_y + radius),    # Left point - wider
                (start_x + radius/1.2, start_y + radius),    # Right point - wider
                (start_x, start_y + radius * 3.5)            # Bottom point - much longer
            ]
            
            rotated_points = []
            for px, py in triangle_base:
                dx = px - start_x
                dy = py - start_y
                rx = dx * math.cos(angle_rad) - dy * math.sin(angle_rad)
                ry = dx * math.sin(angle_rad) + dy * math.cos(angle_rad)
                rotated_points.extend([start_x + rx, start_y + ry])
            
            temp_triangle = self.canvas.create_polygon(
                rotated_points,
                outline=self.bubble_color,
                fill=self.bubble_color,
                width=2
            )
            
            self.temp_pin = [temp_circle, temp_triangle]

    def on_drag(self, event):
        """Handle mouse drag events"""
        if self.bubble_style_var.get() == "pin" and hasattr(self, 'pin_start'):
            canvas_event = self.create_event_with_canvas_coords(event)
            self.update_temp_pin(canvas_event)

    def on_release(self, event):
        """Handle mouse release events"""
        if self.bubble_style_var.get() == "pin" and hasattr(self, 'pin_start'):
            canvas_event = self.create_event_with_canvas_coords(event)
            self.draw_directional_pin(canvas_event)

    def save_as_template(self):
        """Save current bubble configuration as template"""
        template_name = simpledialog.askstring("Template Name", "Enter template name:")
        if template_name:
            template = {
                'size': self.bubble_size,
                'color': self.bubble_color,
                'style': self.bubble_style_var.get(),
                'fill': self.fill_var.get()
            }
            # Save to templates file
            self.save_template(template_name, template)

    def load_template(self):
        """Load saved bubble template"""
        templates = self.load_templates()
        if templates:
            template_name = simpledialog.askstring(
                "Load Template", 
                f"Enter template name ({', '.join(templates.keys())}):"
            )
            if template_name in templates:
                template = templates[template_name]
                self.apply_template(template)

    def save_template(self, template_name, template_data):
        """Save template to JSON file"""
        templates = self.load_templates()
        templates[template_name] = template_data
        
        try:
            with open('bubble_templates.json', 'w') as f:
                json.dump(templates, f)
            messagebox.showinfo("Success", f"Template '{template_name}' saved successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save template: {e}")

    def load_templates(self):
        """Load all saved templates"""
        if os.path.exists('bubble_templates.json'):
            try:
                with open('bubble_templates.json', 'r') as f:
                    return json.load(f)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load templates: {e}")
        return {}

    def apply_template(self, template):
        """Apply loaded template settings"""
        self.bubble_size = template['size']
        self.bubble_size_entry.delete(0, tk.END)
        self.bubble_size_entry.insert(0, str(self.bubble_size))
        
        self.bubble_color = template['color']
        self.bubble_style_var.set(template['style'])
        self.fill_var.set(template['fill'])

    def save_drawing_with_template(self):
        """Save current drawing configuration as template"""
        template_name = simpledialog.askstring("Template Name", "Enter template name:")
        if template_name:
            # Save bubble positions and properties
            bubbles = []
            for element in self.drawn_elements:
                if element[0] == "bubble":
                    _, bubble_ids, text_id, x, y, size, color, number, style, fill, *extra = element
                    bubble_data = {
                        'x': x,
                        'y': y,
                        'size': size,
                        'color': color,
                        'number': number,
                        'style': style,
                        'fill': fill
                    }
                    
                    # Handle pin rotation
                    if style == "pin":
                        # Get rotation from the element if it exists
                        if len(extra) > 0:
                            bubble_data['rotation'] = extra[0]
                        # Fallback to stored rotation angles
                        elif isinstance(bubble_ids, list) and bubble_ids[0] in self.rotation_angles:
                            bubble_data['rotation'] = self.rotation_angles[bubble_ids[0]]
                        else:
                            bubble_data['rotation'] = 0
                    
                    bubbles.append(bubble_data)
            
            template = {
                'bubbles': bubbles,
                'image_name': os.path.basename(self.current_image_path) if hasattr(self, 'current_image_path') else None
            }
            
            self.save_template(template_name, template)

    def load_and_apply_template(self):
        """Load and apply a saved template"""
        templates = self.load_templates()
        if not templates:
            messagebox.showinfo("No Templates", "No saved templates found.")
            return
        
        # Create template selection dialog
        dialog = tk.Toplevel(self.master)
        dialog.title("Select Template")
        dialog.geometry("300x400")
        
        # Create listbox with templates
        listbox = tk.Listbox(dialog)
        listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        for template_name in templates.keys():
            listbox.insert(tk.END, template_name)
        
        def apply_selected():
            selection = listbox.curselection()
            if selection:
                template_name = listbox.get(selection[0])
                template = templates[template_name]
                
                # Check if template matches current image
                if template['image_name'] and hasattr(self, 'current_image_path'):
                    current_image = os.path.basename(self.current_image_path)
                    if template['image_name'] != current_image:
                        if not messagebox.askyesno("Warning", 
                            "This template was created for a different image. Apply anyway?"):
                            dialog.destroy()
                            return
                
                # Clear existing bubbles
                self.reset_canvas()
                if self.canvas_image:
                    self.canvas.delete(self.canvas_image)
                    self.canvas_image = self.canvas.create_image(0, 0, anchor="nw", image=self.image)
                
                # Apply bubbles from template
                for bubble in template['bubbles']:
                    self.bubble_size = bubble['size']
                    self.bubble_color = bubble['color']
                    self.bubble_style_var.set(bubble['style'])
                    self.fill_var.set(bubble['fill'])
                    
                    if bubble['style'] == 'pin':
                        x, y = bubble['x'], bubble['y']
                        radius = bubble['size'] / 2
                        rotation = bubble.get('rotation', 0)
                        
                        # Create circle
                        circle_id = self.canvas.create_oval(
                            x - radius, y - radius,
                            x + radius, y + radius,
                            outline=bubble['color'],
                            fill=bubble['color'] if bubble['fill'] else "",
                            width=2
                        )
                        
                        # Create rotated triangle using the same method as draw_directional_pin
                        triangle_id = self.create_rotated_triangle(x, y, radius, rotation)
                        
                        # Create text
                        text_id = self.canvas.create_text(
                            x, y,
                            text=str(bubble['number']),
                            fill="black"
                        )
                        
                        # Store the element with rotation
                        self.drawn_elements.append((
                            "bubble",
                            [circle_id, triangle_id],
                            text_id,
                            x, y,
                            bubble['size'],
                            bubble['color'],
                            bubble['number'],
                            "pin",
                            bubble['fill'],
                            rotation
                        ))
                        
                        # Store the rotation angle
                        self.rotation_angles[circle_id] = rotation
                        
                    else:
                        # For non-pin bubbles, use the existing draw_bubble method
                        class MockEvent:
                            pass
                        event = MockEvent()
                        event.x = bubble['x']
                        event.y = bubble['y']
                        self.draw_bubble(event)
                    
                    # Update bubble number
                    self.bubble_number = max(self.bubble_number, bubble['number'] + 1)
                
                dialog.destroy()
                messagebox.showinfo("Success", "Template applied successfully!")
        
        # Add apply button
        tk.Button(dialog, text="Apply Template", command=apply_selected).pack(pady=10)

    def delete_template(self):
        """Delete a saved template"""
        templates = self.load_templates()
        if not templates:
            messagebox.showinfo("No Templates", "No saved templates found.")
            return
        
        # Create template deletion dialog
        dialog = tk.Toplevel(self.master)
        dialog.title("Delete Template")
        dialog.geometry("300x400")
        
        # Create listbox with templates
        listbox = tk.Listbox(dialog, selectmode=tk.MULTIPLE)
        listbox.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        for template_name in templates.keys():
            listbox.insert(tk.END, template_name)
        
        def delete_selected():
            selection = listbox.curselection()
            if not selection:
                messagebox.showwarning("No Selection", "Please select template(s) to delete.")
                return
            
            template_names = [listbox.get(idx) for idx in selection]
            if messagebox.askyesno("Confirm Delete", 
                                  f"Are you sure you want to delete the following template(s)?\n\n{', '.join(template_names)}"):
                # Delete selected templates
                for template_name in template_names:
                    del templates[template_name]
                
                # Save updated templates
                try:
                    with open('bubble_templates.json', 'w') as f:
                        json.dump(templates, f)
                    messagebox.showinfo("Success", "Selected template(s) deleted successfully!")
                    dialog.destroy()
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to delete template(s): {e}")
        
        # Add buttons
        button_frame = tk.Frame(dialog)
        button_frame.pack(pady=10)
        
        tk.Button(button_frame, text="Delete Selected", command=delete_selected).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT, padx=5)

    def edit_bubble(self, event):
        """Handle editing of existing bubbles when clicked"""
        # Convert window coordinates to canvas coordinates
        x, y = self.get_canvas_coordinates(event)
        
        # Find the clicked bubble
        for i, element in enumerate(self.drawn_elements):
            if element[0] == "bubble":
                _, bubble_ids, text_id, bx, by, size, color, number, style, fill, *extra = element
                radius = size / 2
                
                # Check if click is within bubble bounds
                if (bx - radius <= x <= bx + radius and 
                    by - radius <= y <= by + radius):
                    # Create edit dialog
                    edit_dialog = tk.Toplevel(self.master)
                    edit_dialog.title("Edit Bubble")
                    edit_dialog.geometry("300x400")
                    edit_dialog.transient(self.master)  # Make dialog modal
                    edit_dialog.grab_set()  # Make dialog modal
                    
                    # Size entry
                    tk.Label(edit_dialog, text="Size:").pack(pady=5)
                    size_entry = tk.Entry(edit_dialog)
                    size_entry.insert(0, str(size))
                    size_entry.pack()
                    
                    # Number entry
                    tk.Label(edit_dialog, text="Number (can include text, commas):").pack(pady=5)
                    number_entry = tk.Entry(edit_dialog)
                    number_entry.insert(0, str(number))
                    number_entry.pack()
                    
                    # Style dropdown
                    tk.Label(edit_dialog, text="Style:").pack(pady=5)
                    style_var = tk.StringVar(value=style)
                    styles = ["circle", "square", "diamond", "hexagon", "star", "pin"]
                    style_dropdown = ttk.Combobox(edit_dialog, textvariable=style_var, values=styles)
                    style_dropdown.pack()
                    
                    # Fill checkbox
                    fill_var = tk.BooleanVar(value=fill)
                    fill_check = tk.Checkbutton(edit_dialog, text="Fill Bubble", variable=fill_var)
                    fill_check.pack(pady=5)
                    
                    # Color display and button
                    color_frame = tk.Frame(edit_dialog)
                    color_frame.pack(pady=5)
                    
                    color_preview = tk.Label(color_frame, text="Current Color", width=20, height=2)
                    color_preview.pack(side=tk.LEFT, padx=5)
                    
                    current_color = color
                    
                    def update_color_preview():
                        color_preview.config(bg=current_color)
                    
                    def choose_color():
                        nonlocal current_color
                        color_result = colorchooser.askcolor(color=current_color, parent=edit_dialog)
                        if color_result[1]:
                            current_color = color_result[1]
                            update_color_preview()
                    
                    update_color_preview()  # Initial color preview
                    tk.Button(color_frame, text="Choose Color", command=choose_color).pack(side=tk.LEFT, padx=5)
                    
                    def apply_changes():
                        try:
                            new_size = int(size_entry.get())
                            if new_size <= 0:
                                raise ValueError("Size must be positive")
                            
                            # Get the number value - can be any string or number
                            new_number = number_entry.get().strip()
                            if not new_number:
                                raise ValueError("Number cannot be empty")
                            
                            new_style = style_var.get()
                            new_fill = fill_var.get()
                            
                            # Store original position and properties
                            original_x = bx
                            original_y = by
                            original_number = self.bubble_number
                            original_color = self.bubble_color
                            original_size = self.bubble_size
                            original_style = self.bubble_style_var.get()
                            original_fill = self.fill_var.get()
                            
                            # Delete old bubble
                            if isinstance(bubble_ids, list):
                                for bid in bubble_ids:
                                    self.canvas.delete(bid)
                            else:
                                self.canvas.delete(bubble_ids)
                            self.canvas.delete(text_id)
                            
                            # Remove old bubble from drawn_elements
                            self.drawn_elements.pop(i)
                            
                            # Set new properties
                            self.bubble_size = new_size
                            self.bubble_color = current_color
                            self.bubble_style_var.set(new_style)
                            self.fill_var.set(new_fill)
                            
                            if new_style == "pin":
                                # For pin style, preserve rotation if it existed
                                rotation = extra[0] if extra else 0
                                
                                # Draw the pin
                                radius = new_size / 2
                                fill_color = current_color if new_fill else ""
                                
                                # Create circle part
                                circle_id = self.canvas.create_oval(
                                    original_x - radius, original_y - radius,
                                    original_x + radius, original_y + radius,
                                    outline=current_color, fill=fill_color, width=2
                                )
                                
                                # Create triangle with rotation
                                angle_rad = math.radians(rotation)
                                triangle_base = [
                                    (original_x - radius/2, original_y + radius),      # Left point
                                    (original_x + radius/2, original_y + radius),      # Right point
                                    (original_x, original_y + radius * 3)              # Bottom point
                                ]
                                
                                # Rotate points around center
                                rotated_points = []
                                for px, py in triangle_base:
                                    dx = px - original_x
                                    dy = py - original_y
                                    rx = dx * math.cos(angle_rad) - dy * math.sin(angle_rad)
                                    ry = dx * math.sin(angle_rad) + dy * math.cos(angle_rad)
                                    rotated_points.extend([original_x + rx, original_y + ry])
                                
                                # Create rotated triangle
                                triangle_id = self.canvas.create_polygon(
                                    rotated_points,
                                    outline=current_color,
                                    fill=current_color,
                                    width=2
                                )
                                
                                # Add text
                                new_text_id = self.canvas.create_text(
                                    original_x, original_y,
                                    text=str(new_number),
                                    fill="black"
                                )
                                
                                # Store the new pin
                                self.drawn_elements.append((
                                    "bubble",
                                    [circle_id, triangle_id],
                                    new_text_id,
                                    original_x, original_y,
                                    new_size,
                                    current_color,
                                    new_number,
                                    "pin",
                                    new_fill,
                                    rotation
                                ))
                                
                                # Store the rotation angle
                                self.rotation_angles[circle_id] = rotation
                                
                            else:
                                # For non-pin bubbles
                                radius = new_size / 2
                                fill_color = current_color if new_fill else ""
                                
                                if new_style == "circle":
                                    bubble_id = self.canvas.create_oval(
                                        original_x - radius, original_y - radius,
                                        original_x + radius, original_y + radius,
                                        outline=current_color, fill=fill_color, width=2
                                    )
                                elif new_style == "square":
                                    bubble_id = self.canvas.create_rectangle(
                                        original_x - radius, original_y - radius,
                                        original_x + radius, original_y + radius,
                                        outline=current_color, fill=fill_color, width=2
                                    )
                                elif new_style == "diamond":
                                    points = [
                                        original_x, original_y - radius,  # top
                                        original_x + radius, original_y,  # right
                                        original_x, original_y + radius,  # bottom
                                        original_x - radius, original_y   # left
                                    ]
                                    bubble_id = self.canvas.create_polygon(
                                        points, outline=current_color, fill=fill_color,
                                        width=2, smooth=False
                                    )
                                elif new_style == "hexagon":
                                    r = radius
                                    points = [
                                        (original_x - r/2, original_y - r),
                                        (original_x + r/2, original_y - r),
                                        (original_x + r, original_y),
                                        (original_x + r/2, original_y + r),
                                        (original_x - r/2, original_y + r),
                                        (original_x - r, original_y)
                                    ]
                                    bubble_id = self.canvas.create_polygon(
                                        points, outline=current_color, fill=fill_color,
                                        width=2, smooth=False
                                    )
                                elif new_style == "star":
                                    points = self._calculate_star_points(original_x, original_y, radius)
                                    bubble_id = self.canvas.create_polygon(
                                        points, outline=current_color, fill=fill_color,
                                        width=2, smooth=False
                                    )
                                
                                # Add text
                                new_text_id = self.canvas.create_text(
                                    original_x, original_y,
                                    text=str(new_number),
                                    fill="black"
                                )
                                
                                # Store in drawn_elements
                                self.drawn_elements.append((
                                    "bubble",
                                    bubble_id,
                                    new_text_id,
                                    original_x, original_y,
                                    new_size,
                                    current_color,
                                    new_number,
                                    new_style,
                                    new_fill
                                ))
                            
                            # Restore original properties
                            self.bubble_size = original_size
                            self.bubble_color = original_color
                            self.bubble_style_var.set(original_style)
                            self.fill_var.set(original_fill)
                            self.bubble_number = original_number
                            
                            # Update canvas
                            self.canvas.update()
                            
                            edit_dialog.destroy()
                            
                        except ValueError as e:
                            messagebox.showerror("Error", str(e) if str(e) != "invalid literal for int() with base 10" 
                                               else "Please enter a valid positive number for size")
                        except Exception as e:
                            messagebox.showerror("Error", f"An error occurred: {str(e)}")
                    
                    # Apply and Cancel buttons
                    button_frame = tk.Frame(edit_dialog)
                    button_frame.pack(pady=10)
                    tk.Button(button_frame, text="Apply", command=apply_changes).pack(side=tk.LEFT, padx=5)
                    tk.Button(button_frame, text="Cancel", command=edit_dialog.destroy).pack(side=tk.LEFT, padx=5)
                    
                    break

    def get_canvas_coordinates(self, event):
        """Convert window coordinates to canvas coordinates"""
        # Get the canvas' current scroll position
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        return x, y

    def _on_mousewheel(self, event):
        """Handle mouse wheel scrolling"""
        scroll_amount = 1 if (event.num == 5 or event.delta < 0) else -1
        
        if event.state & 0x4:  # Check if Ctrl key is pressed
            # Horizontal scroll
            self.canvas.xview_scroll(scroll_amount, "units")
        else:
            # Vertical scroll
            self.canvas.yview_scroll(scroll_amount, "units")

    def create_event_with_canvas_coords(self, event):
        """Create a new event object with canvas coordinates"""
        canvas_x, canvas_y = self.get_canvas_coordinates(event)
        new_event = type('Event', (), {})()
        new_event.x = canvas_x
        new_event.y = canvas_y
        new_event.state = event.state if hasattr(event, 'state') else 0
        return new_event

    def delete_selected(self, event=None):
        """Delete selected elements"""
        selected = []
        for i, element in enumerate(self.drawn_elements):
            if element[0] == "bubble":
                _, bubble_ids, text_id, x, y, size, color, number, style, fill = element[:10]
                # Check if any part of the bubble is selected
                if isinstance(bubble_ids, list):  # For pins
                    for bid in bubble_ids:
                        if self.canvas.itemcget(bid, 'fill') == 'lightblue':  # Selection color
                            selected.append(i)
                            break
                else:  # For other shapes
                    if self.canvas.itemcget(bubble_ids, 'fill') == 'lightblue':  # Selection color
                        selected.append(i)
        
        # Remove selected elements in reverse order
        for index in reversed(selected):
            element = self.drawn_elements[index]
            if element[0] == "bubble":
                _, bubble_ids, text_id, *_ = element
                if isinstance(bubble_ids, list):
                    for bid in bubble_ids:
                        self.canvas.delete(bid)
                else:
                    self.canvas.delete(bubble_ids)
                self.canvas.delete(text_id)
            self.drawn_elements.pop(index)

    def select_all(self, event=None):
        """Select all elements on canvas"""
        for element in self.drawn_elements:
            if element[0] == "bubble":
                _, bubble_ids, text_id, *_ = element
                if isinstance(bubble_ids, list):  # For pins
                    for bid in bubble_ids:
                        self.canvas.itemconfig(bid, fill='lightblue')  # Selection color
                else:  # For other shapes
                    self.canvas.itemconfig(bubble_ids, fill='lightblue')  # Selection color

    def toggle_grid(self, event=None):
        """Toggle grid visibility on canvas"""
        if not hasattr(self, 'grid_visible'):
            self.grid_visible = False
            self.grid_size = 50  # Grid size in pixels
            self.grid_lines = []

        if not self.grid_visible:
            # Create grid lines
            width = int(self.canvas.winfo_width())
            height = int(self.canvas.winfo_height())
            
            # Vertical lines
            for x in range(0, width, self.grid_size):
                line = self.canvas.create_line(x, 0, x, height, fill='gray90', dash=(2, 2))
                self.grid_lines.append(line)
            
            # Horizontal lines
            for y in range(0, height, self.grid_size):
                line = self.canvas.create_line(0, y, width, y, fill='gray90', dash=(2, 2))
                self.grid_lines.append(line)
            
            self.grid_visible = True
        else:
            # Remove grid lines
            for line in self.grid_lines:
                self.canvas.delete(line)
            self.grid_lines = []
            self.grid_visible = False

    def show_help(self):
        """Show help information in a new window with enhanced styling"""
        help_window = tk.Toplevel(self.master)
        help_window.title("Help - Bubble and Stamp App")
        help_window.geometry("800x700")
        help_window.configure(bg='#E3F2FD')  # Light blue background
        
        # Create main container with padding
        main_container = tk.Frame(help_window, bg='#E3F2FD')
        main_container.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Create title with animation
        title_frame = tk.Frame(main_container, bg='#E3F2FD')
        title_frame.pack(fill=tk.X, pady=(0, 20))
        
        title_label = tk.Label(title_frame, text="Bubble and Stamp App Help Guide",
                             font=('Segoe UI', 16, 'bold'),
                             fg='#1565C0', bg='#E3F2FD')
        title_label.pack()
        
        # Add subtle animation to title
        def animate_title():
            colors = ['#1565C0', '#1976D2', '#2196F3', '#1976D2']
            for color in colors:
                title_label.config(fg=color)
                title_label.after(500)
        
        title_label.after(1000, animate_title)
        
        # Create frame with scrollbar
        frame = tk.Frame(main_container, bg='white', relief=tk.RIDGE, borderwidth=1)
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Add scrollbar
        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Create text widget with improved styling
        text = tk.Text(frame, wrap=tk.WORD, yscrollcommand=scrollbar.set,
                      font=('Segoe UI', 10),
                      bg='white',
                      fg='#212121',
                      padx=15,
                      pady=15,
                      spacing1=5,  # Space between paragraphs
                      spacing2=2)  # Space between lines
        text.pack(fill=tk.BOTH, expand=True)
        
        scrollbar.config(command=text.yview)
        
        # Help content with sections
        help_sections = {
            "Quick Start": """
• Upload an image/PDF: Ctrl+O or Upload File button
• Choose bubble style, size, and color from left panel
• Click canvas to place bubbles
• Add stamps and customize as needed
• Save (Ctrl+S) or print (Ctrl+P) your work
""",
            "Keyboard Shortcuts": """
• F1          - Show this help window
• Ctrl + O    - Upload file
• Ctrl + S    - Save drawing
• Ctrl + Z    - Undo last action
• Ctrl + A    - Select all bubbles
• Delete      - Delete selected bubbles
• Ctrl + G    - Toggle grid
• Ctrl + P    - Print drawing
• Escape      - Close dialogs
""",
            "Bubble Features": """
• Multiple styles: Circle, Square, Diamond, Hexagon, Star, Pin
• Customizable size and color with live preview
• Auto-incrementing or custom numbering
• Fill option for all styles
• Pin style with rotation capability
• Edit existing bubbles with Ctrl+Click
""",
            "Selection and Editing": """
• Shift + Click: Select/deselect individual bubbles
• Ctrl + Click: Open bubble editor
• Drag selected bubbles to move them
• Delete key removes selected bubbles
• Multi-select supported for group operations
""",
            "Pin Style Features": """
• Click and drag to set initial direction
• Click on pin to rotate after placement
• Adjustable head and tail sizes
• Rotation preserved in templates
• Custom rotation angles supported
""",
            "Stamp Features": """
• Built-in stamps: MYPL, NPD
• Custom text stamps with formatting
• Date and control information for MYPL
• Adjustable size and color
• Multiple stamps per drawing
""",
            "Template System": """
• Save frequently used configurations
• Load templates for quick setup
• Save complete bubble layouts
• Delete unused templates
• Template preview before applying
""",
            "File Operations": """
• Supported formats: JPG, PNG, PDF
• High-quality image export
• PDF conversion with preserved quality
• Print preview available
• Multiple save formats
""",
            "Email Integration": """
• Direct email sending capability
• CC and BCC support
• Template-based emails
• Attachment format options
• Email history tracking
• Preview before sending
""",
            "Additional Features": """
• Undo/Redo support
• High-DPI display support
• Auto-save functionality
• Batch operations
• Export to multiple formats
""",
            "Support Contact": """
Contact: Manish Vijay
Mobile: +917062040094
Email: Available in Contact Us
"""
        }

        # Add content with styling
        text.tag_configure("section_title", font=('Segoe UI', 11, 'bold'), foreground='#1565C0')
        text.tag_configure("section_content", font=('Segoe UI', 10), foreground='#212121', spacing1=10)
        
        for section, content in help_sections.items():
            text.insert(tk.END, f"\n{section}\n", "section_title")
            text.insert(tk.END, f"{content}\n", "section_content")
        
        # Make text read-only
        text.config(state='disabled')
        
        # Create button frame with modern styling
        button_frame = tk.Frame(main_container, bg='#E3F2FD')
        button_frame.pack(pady=15)
        
        # Close button with animation
        close_button = tk.Button(button_frame, text="Close",
                               font=('Segoe UI', 10),
                               bg='#2196F3',
                               fg='white',
                               relief=tk.FLAT,
                               padx=20,
                               pady=5,
                               cursor='hand2')
        close_button.pack()
        
        def on_enter(e):
            close_button['background'] = '#1976D2'
            
        def on_leave(e):
            close_button['background'] = '#2196F3'
            
        def on_click():
            # Add fade-out animation
            for i in range(10, -1, -1):
                help_window.attributes('-alpha', i/10)
                help_window.update()
                help_window.after(20)
            help_window.destroy()
        
        close_button.bind('<Enter>', on_enter)
        close_button.bind('<Leave>', on_leave)
        close_button.config(command=on_click)
        
        # Add mousewheel scrolling
        def _on_mousewheel(event):
            text.yview_scroll(int(-1*(event.delta/120)), "units")
        text.bind_all("<MouseWheel>", _on_mousewheel)
        
        # Add search functionality
        search_frame = tk.Frame(main_container, bg='#E3F2FD')
        search_frame.pack(fill=tk.X, pady=(0, 10))
        
        search_entry = tk.Entry(search_frame, font=('Segoe UI', 9))
        search_entry.pack(side=tk.LEFT, padx=5)
        
        def search_text():
            # Remove previous highlights
            text.tag_remove('search', '1.0', tk.END)
            
            search_term = search_entry.get().lower()
            if search_term:
                idx = '1.0'
                while True:
                    idx = text.search(search_term, idx, tk.END, nocase=True)
                    if not idx:
                        break
                    end_idx = f"{idx}+{len(search_term)}c"
                    text.tag_add('search', idx, end_idx)
                    idx = end_idx
                
                text.tag_config('search', background='yellow')
        
        search_button = tk.Button(search_frame, text="Search",
                                font=('Segoe UI', 9),
                                bg='#2196F3',
                                fg='white',
                                relief=tk.FLAT,
                                command=search_text)
        search_button.pack(side=tk.LEFT, padx=5)
        
        # Bind enter key to search
        search_entry.bind('<Return>', lambda e: search_text())
        
        # Center the window
        help_window.update_idletasks()
        width = help_window.winfo_width()
        height = help_window.winfo_height()
        x = (help_window.winfo_screenwidth() // 2) - (width // 2)
        y = (help_window.winfo_screenheight() // 2) - (height // 2)
        help_window.geometry(f'{width}x{height}+{x}+{y}')
        
        # Add window fade-in effect
        help_window.attributes('-alpha', 0.0)
        for i in range(11):
            help_window.attributes('-alpha', i/10)
            help_window.update()
            help_window.after(20)
        
        # Make window modal
        help_window.transient(self.master)
        help_window.grab_set()
        
        # Bind escape key to close
        help_window.bind('<Escape>', lambda e: on_click())

    def load_email_settings(self):
        """Load email settings from file"""
        try:
            if os.path.exists('email_settings.json'):
                with open('email_settings.json', 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return {'email': '', 'password': '', 'suggestion_recipient': 'manishvijay917@gmail.com'}

    def save_email_settings(self):
        """Save email settings to file"""
        try:
            with open('email_settings.json', 'w') as f:
                json.dump(self.email_settings, f)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save email settings: {e}")

    def configure_email(self):
        """Configure email settings"""
        dialog = tk.Toplevel(self.master)
        dialog.title("Email Settings")
        dialog.geometry("300x300")
        dialog.transient(self.master)
        dialog.grab_set()

        tk.Label(dialog, text="Gmail Address:").pack(pady=5)
        email_entry = tk.Entry(dialog, width=40)
        email_entry.insert(0, self.email_settings.get('email', ''))
        email_entry.pack(pady=5)

        tk.Label(dialog, text="App Password:").pack(pady=5)
        password_entry = tk.Entry(dialog, width=40, show='*')
        password_entry.insert(0, self.email_settings.get('password', ''))
        password_entry.pack(pady=5)

        tk.Label(dialog, text="Suggestion Recipient Email:").pack(pady=5)
        suggestion_entry = tk.Entry(dialog, width=40)
        suggestion_entry.insert(0, self.email_settings.get('suggestion_recipient', 'manishvijay917@gmail.com'))
        suggestion_entry.pack(pady=5)

        def save_settings():
            self.email_settings['email'] = email_entry.get()
            self.email_settings['password'] = password_entry.get()
            self.email_settings['suggestion_recipient'] = suggestion_entry.get()
            self.save_email_settings()
            dialog.destroy()
            messagebox.showinfo("Success", "Email settings saved successfully!")

        tk.Button(dialog, text="Save", command=save_settings).pack(pady=20)

    def load_saved_emails(self):
        """Load saved email addresses from file"""
        try:
            if os.path.exists('saved_emails.json'):
                with open('saved_emails.json', 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return []

    def save_email_addresses(self):
        """Save email addresses to file"""
        try:
            with open('saved_emails.json', 'w') as f:
                json.dump(self.saved_emails, f)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save email addresses: {e}")

    def add_to_saved_emails(self, email):
        """Add an email to saved emails if it's not already there"""
        if email and email not in self.saved_emails:
            self.saved_emails.append(email)
            if len(self.saved_emails) > 10:  # Keep only last 10 emails
                self.saved_emails.pop(0)
            self.save_email_addresses()

    def load_saved_cc_emails(self):
        """Load saved CC email addresses from file"""
        try:
            if os.path.exists('saved_cc_emails.json'):
                with open('saved_cc_emails.json', 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return []

    def load_saved_bcc_emails(self):
        """Load saved BCC email addresses from file"""
        try:
            if os.path.exists('saved_bcc_emails.json'):
                with open('saved_bcc_emails.json', 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return []

    def save_cc_email_addresses(self):
        """Save CC email addresses to file"""
        try:
            with open('saved_cc_emails.json', 'w') as f:
                json.dump(self.saved_cc_emails, f)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save CC email addresses: {e}")

    def save_bcc_email_addresses(self):
        """Save BCC email addresses to file"""
        try:
            with open('saved_bcc_emails.json', 'w') as f:
                json.dump(self.saved_bcc_emails, f)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save BCC email addresses: {e}")

    def add_to_saved_cc_emails(self, email):
        """Add an email to saved CC emails if it's not already there"""
        if email and email not in self.saved_cc_emails:
            self.saved_cc_emails.append(email)
            if len(self.saved_cc_emails) > 10:  # Keep only last 10 emails
                self.saved_cc_emails.pop(0)
            self.save_cc_email_addresses()

    def add_to_saved_bcc_emails(self, email):
        """Add an email to saved BCC emails if it's not already there"""
        if email and email not in self.saved_bcc_emails:
            self.saved_bcc_emails.append(email)
            if len(self.saved_bcc_emails) > 10:  # Keep only last 10 emails
                self.saved_bcc_emails.pop(0)
            self.save_bcc_email_addresses()

    def create_email_field(self, parent, label_text, entry_width=30, saved_emails=None):
        """Create an email field with label, entry, and combobox"""
        frame = tk.Frame(parent)
        frame.pack(fill=tk.X, padx=10, pady=5)

        tk.Label(frame, text=label_text).pack(side=tk.LEFT, padx=5)
        entry = tk.Entry(frame, width=entry_width)
        entry.pack(side=tk.LEFT, padx=5)

        if saved_emails is not None:
            combo_var = tk.StringVar()
            combo = ttk.Combobox(frame, textvariable=combo_var, 
                               values=saved_emails, width=entry_width)
            combo.pack(side=tk.LEFT, padx=5)
            combo.set("Select from saved emails")

            def on_select(event):
                selected = combo.get()
                if selected and selected != "Select from saved emails":
                    entry.delete(0, tk.END)
                    entry.insert(0, selected)

            combo.bind('<<ComboboxSelected>>', on_select)
            return entry, combo
        return entry

    def load_email_history(self):
        """Load email history from file"""
        try:
            if os.path.exists('email_history.json'):
                with open('email_history.json', 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return []

    def save_email_history(self):
        """Save email history to file"""
        try:
            with open('email_history.json', 'w') as f:
                json.dump(self.email_history, f)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save email history: {e}")

    def add_to_email_history(self, email_data):
        """Add an email to history"""
        self.email_history.append(email_data)
        if len(self.email_history) > 50:  # Keep only last 50 emails
            self.email_history.pop(0)
        self.save_email_history()

    def show_email_history(self):
        """Show email history in a new window"""
        history_window = tk.Toplevel(self.master)
        history_window.title("Email History")
        history_window.geometry("800x600")
        history_window.transient(self.master)  # Make dialog modal
        history_window.grab_set()  # Make dialog modal

        # Create main frame
        main_frame = tk.Frame(history_window)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Create frame with scrollbar
        tree_frame = tk.Frame(main_frame)
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        # Add scrollbar
        scrollbar = tk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Create treeview
        columns = ("Date", "Recipients", "Subject", "Format")
        tree = ttk.Treeview(tree_frame, columns=columns, show="headings", yscrollcommand=scrollbar.set)
        tree.pack(fill=tk.BOTH, expand=True)

        # Configure scrollbar
        scrollbar.config(command=tree.yview)

        # Set column headings
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150)

        # Add data to treeview
        for email in reversed(self.email_history):
            recipients = email['to']
            if email.get('cc'):
                recipients += f" (CC: {email['cc']})"
            if email.get('bcc'):
                recipients += f" (BCC: {email['bcc']})"
            
            tree.insert("", "end", values=(
                email['date'],
                recipients,
                email['subject'],
                email['format']
            ))

        def resend_email():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("No Selection", "Please select an email to resend")
                return

            item = tree.item(selected[0])
            date = item['values'][0]
            
            # Find the email data in history
            email_data = None
            for email in self.email_history:
                if email['date'] == date:
                    email_data = email
                    break

            if email_data:
                self.send_email(preset_data=email_data)
                history_window.destroy()  # Close history window after resending

        # Create button frame
        button_frame = tk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=10)

        # Add Resend button
        resend_button = tk.Button(button_frame, text="Resend Selected", command=resend_email,
                                bg='#2196F3', fg='white', font=('Segoe UI', 9, 'bold'))
        resend_button.pack(side=tk.LEFT, padx=5)

        # Add Close button
        close_button = tk.Button(button_frame, text="Close", command=history_window.destroy,
                               bg='#f44336', fg='white', font=('Segoe UI', 9, 'bold'))
        close_button.pack(side=tk.RIGHT, padx=5)

        # Add double-click binding for resending
        tree.bind('<Double-1>', lambda e: resend_email())

    def preview_email(self, to_emails, cc_emails, bcc_emails, subject, message, attachment_info):
        """Show email preview in a new window"""
        preview_window = tk.Toplevel(self.master)
        preview_window.title("Email Preview")
        preview_window.geometry("600x700")
        preview_window.transient(self.master)  # Make dialog modal
        preview_window.grab_set()  # Make dialog modal

        # Create main frame with padding
        main_frame = tk.Frame(preview_window)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # Create scrollable frame
        canvas = tk.Canvas(main_frame)
        scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        # Header section
        header_frame = tk.LabelFrame(scrollable_frame, text="Email Details", padx=10, pady=10)
        header_frame.pack(fill=tk.X, pady=(0, 20))

        # From
        tk.Label(header_frame, text="From:", font=('Segoe UI', 9, 'bold')).pack(anchor='w')
        tk.Label(header_frame, text=self.email_settings['email']).pack(anchor='w', padx=20)

        # To
        tk.Label(header_frame, text="To:", font=('Segoe UI', 9, 'bold')).pack(anchor='w')
        tk.Label(header_frame, text=', '.join(to_emails)).pack(anchor='w', padx=20)

        # CC
        if cc_emails:
            tk.Label(header_frame, text="CC:", font=('Segoe UI', 9, 'bold')).pack(anchor='w')
            tk.Label(header_frame, text=', '.join(cc_emails)).pack(anchor='w', padx=20)

        # BCC
        if bcc_emails:
            tk.Label(header_frame, text="BCC:", font=('Segoe UI', 9, 'bold')).pack(anchor='w')
            tk.Label(header_frame, text=', '.join(bcc_emails)).pack(anchor='w', padx=20)

        # Subject
        tk.Label(header_frame, text="Subject:", font=('Segoe UI', 9, 'bold')).pack(anchor='w')
        tk.Label(header_frame, text=subject).pack(anchor='w', padx=20)

        # Message section
        message_frame = tk.LabelFrame(scrollable_frame, text="Message", padx=10, pady=10)
        message_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 20))

        message_text = tk.Text(message_frame, wrap=tk.WORD, height=10)
        message_text.pack(fill=tk.BOTH, expand=True)
        message_text.insert('1.0', message)
        message_text.config(state='disabled')

        # Attachment section
        attachment_frame = tk.LabelFrame(scrollable_frame, text="Attachment", padx=10, pady=10)
        attachment_frame.pack(fill=tk.X)

        tk.Label(attachment_frame, text=f"File: drawing.{attachment_info['format']}").pack(anchor='w')
        tk.Label(attachment_frame, text=f"Size: {attachment_info['size']:.1f} KB").pack(anchor='w')
        tk.Label(attachment_frame, text=f"Format: {attachment_info['format'].upper()}").pack(anchor='w')

        # Pack the canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Add mousewheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

        # Create button frame at the bottom
        button_frame = tk.Frame(preview_window)
        button_frame.pack(side=tk.BOTTOM, pady=10)

        # Close button
        close_button = tk.Button(
            button_frame, 
            text="Close",
            command=lambda: [preview_window.grab_release(), preview_window.destroy()],
            bg='#f44336',
            fg='white',
            font=('Segoe UI', 9, 'bold'),
            width=15,
            height=1
        )
        close_button.pack(pady=5)

        # Bind escape key to close
        preview_window.bind('<Escape>', lambda e: [preview_window.grab_release(), preview_window.destroy()])

        # Make sure the window is destroyed properly when clicking the X button
        preview_window.protocol("WM_DELETE_WINDOW", lambda: [preview_window.grab_release(), preview_window.destroy()])

    def send_email(self, preset_data=None):
        """Send the current drawing as email attachment"""
        if not self.email_settings.get('email') or not self.email_settings.get('password'):
            if messagebox.askyesno("Email Settings Required", 
                                 "Email settings not configured. Would you like to configure them now?"):
                self.configure_email()
            return

        # Create dialog for email details
        dialog = tk.Toplevel(self.master)
        dialog.title("Send Email")
        dialog.geometry("600x600")
        dialog.transient(self.master)
        dialog.grab_set()

        # Create email fields
        to_entry, to_combo = self.create_email_field(dialog, "To:", saved_emails=self.saved_emails)
        cc_entry, cc_combo = self.create_email_field(dialog, "CC:", saved_emails=self.saved_cc_emails)
        bcc_entry, bcc_combo = self.create_email_field(dialog, "BCC:", saved_emails=self.saved_bcc_emails)

        # Subject
        tk.Label(dialog, text="Subject:").pack(pady=5)
        subject_entry = tk.Entry(dialog, width=70)
        subject_entry.pack(pady=5)

        # Message
        tk.Label(dialog, text="Message:").pack(pady=5)
        message_text = tk.Text(dialog, height=5, width=70)
        message_text.pack(pady=5)

        # File format selection
        format_var = tk.StringVar(value="pdf")
        tk.Label(dialog, text="Send as:").pack(pady=5)
        format_frame = tk.Frame(dialog)
        format_frame.pack()
        tk.Radiobutton(format_frame, text="PDF", variable=format_var, value="pdf").pack(side=tk.LEFT)
        tk.Radiobutton(format_frame, text="Image", variable=format_var, value="jpg").pack(side=tk.LEFT)

        # Fill in preset data if provided
        if preset_data:
            to_entry.insert(0, preset_data['to'])
            if preset_data.get('cc'):
                cc_entry.insert(0, preset_data['cc'])
            if preset_data.get('bcc'):
                bcc_entry.insert(0, preset_data['bcc'])
            subject_entry.insert(0, preset_data['subject'])
            message_text.insert('1.0', preset_data['message'])
            format_var.set(preset_data['format'])

        def preview():
            # Get and validate email addresses
            to_emails = [e.strip() for e in to_entry.get().split(',') if e.strip()]
            cc_emails = [e.strip() for e in cc_entry.get().split(',') if e.strip()]
            bcc_emails = [e.strip() for e in bcc_entry.get().split(',') if e.strip()]

            if not to_emails:
                messagebox.showerror("Error", "Please enter at least one recipient email address")
                return

            # Save current drawing to temporary file to get size
            temp_dir = tempfile.mkdtemp()
            file_format = format_var.get()
            temp_file = os.path.join(temp_dir, f"drawing.{file_format}")
            
            try:
                if file_format == "pdf":
                    self.save_as_pdf(temp_file)
                else:
                    self.save_drawing_to_file(temp_file)

                # Get file size in KB
                file_size = os.path.getsize(temp_file) / 1024

                attachment_info = {
                    'format': file_format,
                    'size': file_size
                }

                self.preview_email(
                    to_emails, cc_emails, bcc_emails,
                    subject_entry.get(),
                    message_text.get("1.0", tk.END),
                    attachment_info
                )
            finally:
                try:
                    os.remove(temp_file)
                    os.rmdir(temp_dir)
                except:
                    pass

        def send():
            try:
                # Get and validate email addresses
                to_emails = [e.strip() for e in to_entry.get().split(',') if e.strip()]
                cc_emails = [e.strip() for e in cc_entry.get().split(',') if e.strip()]
                bcc_emails = [e.strip() for e in bcc_entry.get().split(',') if e.strip()]

                if not to_emails:
                    messagebox.showerror("Error", "Please enter at least one recipient email address")
                    return

                # Save emails to respective lists
                for email in to_emails:
                    self.add_to_saved_emails(email)
                for email in cc_emails:
                    self.add_to_saved_cc_emails(email)
                for email in bcc_emails:
                    self.add_to_saved_bcc_emails(email)

                # Update combobox values
                to_combo['values'] = self.saved_emails
                cc_combo['values'] = self.saved_cc_emails
                bcc_combo['values'] = self.saved_bcc_emails

                # Save current drawing to temporary file
                temp_dir = tempfile.mkdtemp()
                file_format = format_var.get()
                temp_file = os.path.join(temp_dir, f"drawing.{file_format}")
                
                # Save the drawing
                if file_format == "pdf":
                    self.save_as_pdf(temp_file)
                else:
                    self.save_drawing_to_file(temp_file)

                # Create email
                msg = MIMEMultipart()
                msg['From'] = self.email_settings['email']
                msg['To'] = ', '.join(to_emails)
                if cc_emails:
                    msg['Cc'] = ', '.join(cc_emails)
                msg['Subject'] = subject_entry.get()
                msg.attach(MIMEText(message_text.get("1.0", tk.END), 'plain'))

                # Attach file
                with open(temp_file, 'rb') as f:
                    attachment = MIMEApplication(f.read(), _subtype=file_format)
                    attachment.add_header('Content-Disposition', 'attachment', 
                                       filename=f"drawing.{file_format}")
                    msg.attach(attachment)

                # Prepare all recipients
                all_recipients = to_emails + cc_emails + bcc_emails

                # Send email
                with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                    server.starttls()
                    server.login(self.email_settings['email'], self.email_settings['password'])
                    server.send_message(msg, to_addrs=all_recipients)

                # Add to email history
                self.add_to_email_history({
                    'date': date.today().strftime('%Y-%m-%d %H:%M:%S'),
                    'to': ', '.join(to_emails),
                    'cc': ', '.join(cc_emails) if cc_emails else '',
                    'bcc': ', '.join(bcc_emails) if bcc_emails else '',
                    'subject': subject_entry.get(),
                    'message': message_text.get("1.0", tk.END),
                    'format': file_format
                })

                messagebox.showinfo("Success", "Email sent successfully!")
                dialog.destroy()

            except Exception as e:
                messagebox.showerror("Error", f"Failed to send email: {e}")
            finally:
                # Clean up temporary files
                try:
                    os.remove(temp_file)
                    os.rmdir(temp_dir)
                except:
                    pass

        # Add buttons frame
        button_frame = tk.Frame(dialog)
        button_frame.pack(pady=20)

        # History button
        history_button = tk.Button(button_frame, text="Email History", command=self.show_email_history,
                                 bg='#9C27B0', fg='white', font=('Segoe UI', 9, 'bold'))
        history_button.pack(side=tk.LEFT, padx=5)

        # Preview button
        preview_button = tk.Button(button_frame, text="Preview", command=preview,
                                 bg='#FF9800', fg='white', font=('Segoe UI', 9, 'bold'))
        preview_button.pack(side=tk.LEFT, padx=5)

        # Send button
        send_button = tk.Button(button_frame, text="Send", command=send,
                              bg='#4CAF50', fg='white', font=('Segoe UI', 9, 'bold'))
        send_button.pack(side=tk.LEFT, padx=5)

        # Cancel button
        cancel_button = tk.Button(button_frame, text="Cancel", command=dialog.destroy,
                                bg='#f44336', fg='white', font=('Segoe UI', 9, 'bold'))
        cancel_button.pack(side=tk.LEFT, padx=5)

    def save_drawing_to_file(self, file_path):
        """Save the current drawing to a file"""
        # Get the scroll region and canvas dimensions
        scroll_region = self.canvas.bbox("all")
        if not scroll_region:
            scroll_region = (0, 0, 1200, 900)

        width = scroll_region[2] - scroll_region[0]
        height = scroll_region[3] - scroll_region[1]

        # Create a high-resolution image
        scale_factor = 2
        img = Image.new("RGB", (width * scale_factor, height * scale_factor), "white")
        draw = ImageDraw.Draw(img)

        # If there's an original image, paste it first
        if self.original_image:
            resized_original = self.original_image.resize(
                (width * scale_factor, height * scale_factor),
                Image.Resampling.LANCZOS
            )
            img.paste(resized_original, (0, 0))

        # Draw all elements with scaled coordinates and sizes
        for element in self.drawn_elements:
            if element[0] == "bubble":
                _, bubble_ids, text_id, x, y, size, color, number, style, fill = element[:10]
                
                # Scale coordinates relative to scroll region
                scaled_x = (x - scroll_region[0]) * scale_factor
                scaled_y = (y - scroll_region[1]) * scale_factor
                scaled_size = size * scale_factor
                scaled_radius = scaled_size / 2
                
                fill_color = color if fill else None

                if style == "pin":
                    # Get rotation angle
                    rotation = element[10] if len(element) > 10 else 0
                    
                    # Draw circle
                    draw.ellipse(
                        [scaled_x - scaled_radius, scaled_y - scaled_radius,
                         scaled_x + scaled_radius, scaled_y + scaled_radius],
                        outline=color,
                        fill=fill_color,
                        width=max(2, int(2 * scale_factor))
                    )
                    
                    # Draw rotated triangle
                    angle_rad = math.radians(rotation)
                    triangle_base = [
                        (scaled_x - scaled_radius/1.2, scaled_y + scaled_radius),
                        (scaled_x + scaled_radius/1.2, scaled_y + scaled_radius),
                        (scaled_x, scaled_y + scaled_radius * 3.5)
                    ]
                    
                    rotated_points = []
                    for px, py in triangle_base:
                        dx = px - scaled_x
                        dy = py - scaled_y
                        rx = dx * math.cos(angle_rad) - dy * math.sin(angle_rad)
                        ry = dx * math.sin(angle_rad) + dy * math.cos(angle_rad)
                        rotated_points.extend([scaled_x + rx, scaled_y + ry])
                    
                    draw.polygon(
                        rotated_points,
                        outline=color,
                        fill=color,
                        width=max(2, int(2 * scale_factor))
                    )
                
                elif style == "circle":
                    draw.ellipse(
                        [scaled_x - scaled_radius, scaled_y - scaled_radius,
                         scaled_x + scaled_radius, scaled_y + scaled_radius],
                        outline=color,
                        fill=fill_color,
                        width=max(2, int(2 * scale_factor))
                    )
                
                elif style == "square":
                    draw.rectangle(
                        [scaled_x - scaled_radius, scaled_y - scaled_radius,
                         scaled_x + scaled_radius, scaled_y + scaled_radius],
                        outline=color,
                        fill=fill_color,
                        width=max(2, int(2 * scale_factor))
                    )
                
                elif style == "diamond":
                    points = [
                        (scaled_x, scaled_y - scaled_radius),
                        (scaled_x + scaled_radius, scaled_y),
                        (scaled_x, scaled_y + scaled_radius),
                        (scaled_x - scaled_radius, scaled_y)
                    ]
                    draw.polygon(points, outline=color, fill=fill_color)
                
                elif style == "hexagon":
                    r = scaled_radius
                    points = [
                        (scaled_x - r/2, scaled_y - r),
                        (scaled_x + r/2, scaled_y - r),
                        (scaled_x + r, scaled_y),
                        (scaled_x + r/2, scaled_y + r),
                        (scaled_x - r/2, scaled_y + r),
                        (scaled_x - r, scaled_y)
                    ]
                    draw.polygon(points, outline=color, fill=fill_color)
                
                elif style == "star":
                    points = self._calculate_star_points(scaled_x, scaled_y, scaled_radius)
                    point_pairs = [(points[i], points[i+1]) for i in range(0, len(points), 2)]
                    draw.polygon(point_pairs, outline=color, fill=fill_color)

                # Draw number with scaled font size
                font_size = max(int(self.stamp_size * scale_factor), 24)
                font = ImageFont.truetype("arial.ttf", font_size)
                text_bbox = draw.textbbox((0, 0), str(number), font=font)
                text_width = text_bbox[2] - text_bbox[0]
                text_height = text_bbox[3] - text_bbox[1]
                text_x = scaled_x - text_width / 2
                text_y = scaled_y - text_height / 2
                draw.text((text_x, text_y), str(number), fill="black", font=font)

            elif element[0] == "stamp":
                _, stamp_ids = element
                # Get the coordinates of the first stamp element
                x, y = self.canvas.coords(stamp_ids[0])
                
                # Scale coordinates relative to scroll region
                scaled_x = (x - scroll_region[0]) * scale_factor
                scaled_y = (y - scroll_region[1]) * scale_factor
                
                # Calculate font size and create font
                font_size = max(int(self.stamp_size * scale_factor), 24)
                font = ImageFont.truetype("arial.ttf", font_size)
                
                if "MYPL" in self.canvas.itemcget(stamp_ids[0], 'text'):
                    # Get text dimensions for centering
                    text = "MYPL"
                    text_bbox = draw.textbbox((0, 0), text, font=font)
                    text_width = text_bbox[2] - text_bbox[0]
                    
                    # Draw each line of the MYPL stamp
                    draw.text((scaled_x - text_width/2, scaled_y), text, fill=self.stamp_color, font=font)
                    
                    text = "CONTROLLED,IF RED"
                    text_bbox = draw.textbbox((0, 0), text, font=font)
                    text_width = text_bbox[2] - text_bbox[0]
                    draw.text((scaled_x - text_width/2, scaled_y + font_size + 5), text, fill=self.stamp_color, font=font)
                    
                    text = f"ISSUE DATE: {date.today().strftime('%d-%m-%Y')}"
                    text_bbox = draw.textbbox((0, 0), text, font=font)
                    text_width = text_bbox[2] - text_bbox[0]
                    draw.text((scaled_x - text_width/2, scaled_y + (font_size + 5) * 2), text, fill=self.stamp_color, font=font)
                    
                    text = "by Mjoshi"
                    text_bbox = draw.textbbox((0, 0), text, font=font)
                    text_width = text_bbox[2] - text_bbox[0]
                    draw.text((scaled_x - text_width/2, scaled_y + (font_size + 5) * 3), text, fill=self.stamp_color, font=font)
                
                elif "NPD" in self.canvas.itemcget(stamp_ids[0], 'text'):
                    text = "NPD"
                    text_bbox = draw.textbbox((0, 0), text, font=font)
                    text_width = text_bbox[2] - text_bbox[0]
                    draw.text((scaled_x - text_width/2, scaled_y), text, fill=self.stamp_color, font=font)
                else:
                    text = self.canvas.itemcget(stamp_ids[0], 'text')
                    text_bbox = draw.textbbox((0, 0), text, font=font)
                    text_width = text_bbox[2] - text_bbox[0]
                    draw.text((scaled_x - text_width/2, scaled_y), text, fill=self.stamp_color, font=font)

        img.save(file_path, quality=95)

    def save_as_pdf(self, file_path):
        """Save the current drawing as PDF"""
        # First save as image
        temp_img_path = file_path.replace('.pdf', '.jpg')
        self.save_drawing_to_file(temp_img_path)

        # Convert image to PDF
        img = Image.open(temp_img_path)
        img.convert('RGB').save(file_path, 'PDF', resolution=100.0)

        # Clean up temporary image file
        try:
            os.remove(temp_img_path)
        except:
            pass

    def show_chatbot(self):
        """Show the chatbot window as a popup above the chat icon"""
        # Create chat window
        chat_window = tk.Toplevel(self.master)
        chat_window.title("Chat Assistant")
        
        # Set window size
        window_width = 300
        window_height = 400
        
        # Get chat icon position (it's in bottom-right)
        icon_size = 48
        padding = 20
        screen_width = chat_window.winfo_screenwidth()
        screen_height = chat_window.winfo_screenheight()
        
        # Position window above the chat icon
        x = screen_width - window_width - padding
        y = screen_height - window_height - icon_size - (padding * 2) - 10  # Extra 10px gap
        chat_window.geometry(f"{window_width}x{window_height}+{x}+{y}")
        
        # Configure window
        chat_window.configure(bg='#F5F5F5')
        chat_window.overrideredirect(True)  # Remove window decorations
        
        # Create title bar
        title_bar = tk.Frame(chat_window, bg='#2196F3', height=40)
        title_bar.pack(fill=tk.X)
        title_bar.pack_propagate(False)
        
        # Add title and close button to title bar
        tk.Label(title_bar, text="Chat Assistant", 
                font=('Segoe UI', 11, 'bold'), 
                fg='white', bg='#2196F3').pack(side=tk.LEFT, padx=10)
        
        close_btn = tk.Label(title_bar, text="×", 
                           font=('Segoe UI', 16), 
                           fg='white', bg='#2196F3',
                           cursor='hand2')
        close_btn.pack(side=tk.RIGHT, padx=10)
        
        # Add close button functionality
        def close_window(e=None):
            # Add fade out effect
            for i in range(10, -1, -1):
                chat_window.attributes('-alpha', i/10)
                chat_window.update()
                chat_window.after(20)
            chat_window.destroy()
            
        close_btn.bind('<Button-1>', close_window)
        
        # Add hover effect to close button
        def on_close_enter(e):
            close_btn.configure(fg='#E3F2FD')
            
        def on_close_leave(e):
            close_btn.configure(fg='white')
            
        close_btn.bind('<Enter>', on_close_enter)
        close_btn.bind('<Leave>', on_close_leave)
        
        # Make window draggable
        def start_move(event):
            chat_window.x = event.x
            chat_window.y = event.y

        def stop_move(event):
            chat_window.x = None
            chat_window.y = None

        def do_move(event):
            deltax = event.x - chat_window.x
            deltay = event.y - chat_window.y
            x = chat_window.winfo_x() + deltax
            y = chat_window.winfo_y() + deltay
            chat_window.geometry(f"+{x}+{y}")

        title_bar.bind('<Button-1>', start_move)
        title_bar.bind('<ButtonRelease-1>', stop_move)
        title_bar.bind('<B1-Motion>', do_move)
        
        # Create chat display
        chat_frame = tk.Frame(chat_window, bg='#F5F5F5')
        chat_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Create canvas and scrollbar for chat
        chat_canvas = tk.Canvas(chat_frame, bg='#F5F5F5', highlightthickness=0)
        scrollbar = ttk.Scrollbar(chat_frame, orient="vertical", command=chat_canvas.yview)
        chat_canvas.configure(yscrollcommand=scrollbar.set)
        
        # Create message frame inside canvas
        message_frame = tk.Frame(chat_canvas, bg='#F5F5F5')
        chat_canvas.create_window((0, 0), window=message_frame, anchor="nw")
        
        # Configure grid
        chat_frame.grid_rowconfigure(0, weight=1)
        chat_frame.grid_columnconfigure(0, weight=1)
        chat_canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        
        def on_frame_configure(event):
            chat_canvas.configure(scrollregion=chat_canvas.bbox("all"))
            chat_canvas.configure(width=chat_frame.winfo_width()-scrollbar.winfo_width())
        
        message_frame.bind("<Configure>", on_frame_configure)
        
        # Create input area
        input_frame = tk.Frame(chat_window, bg='white')
        input_frame.pack(fill=tk.X, side=tk.BOTTOM, padx=10, pady=10)
        
        # Create text input
        text_input = tk.Text(input_frame, height=2, font=('Segoe UI', 10),
                            bg='white', fg='#424242', relief=tk.FLAT)
        text_input.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create send button
        send_button = tk.Button(input_frame, text="Send", width=8,
                              bg='#2196F3', fg='white', relief=tk.FLAT,
                              font=('Segoe UI', 10))
        send_button.pack(side=tk.RIGHT, padx=5)
        
        def add_message(message, is_user=True):
            msg_frame = tk.Frame(message_frame, bg='#F5F5F5')
            msg_frame.pack(fill=tk.X, padx=10, pady=4)
            
            # Create message container with avatar
            msg_container = tk.Frame(msg_frame, bg='#F5F5F5')
            msg_container.pack(anchor='e' if is_user else 'w')
            
            if not is_user:
                # Bot avatar
                avatar_size = 28
                avatar = tk.Canvas(msg_container, width=avatar_size, height=avatar_size,
                                bg='#F5F5F5', highlightthickness=0)
                avatar.pack(side=tk.LEFT, padx=(0, 8))
                
                # Draw avatar background
                avatar.create_oval(2, 2, avatar_size-2, avatar_size-2,
                                fill='#2196F3', outline='#2196F3')
                
                # Draw robot icon
                avatar.create_rectangle(8, 6, 20, 16,
                                    fill='white', outline='white')
                avatar.create_rectangle(11, 16, 17, 19,
                                    fill='white', outline='white')
                # Eyes
                avatar.create_oval(10, 9, 13, 12, fill='#2196F3', outline='#2196F3')
                avatar.create_oval(15, 9, 18, 12, fill='#2196F3', outline='#2196F3')
            
            # Message bubble with timestamp
            bubble_frame = tk.Frame(msg_container, bg='#F5F5F5')
            bubble_frame.pack(side=tk.RIGHT if is_user else tk.LEFT)
            
            # Get current time
            timestamp = datetime.now().strftime('%H:%M')
            
            if is_user:
                msg_bg = '#2196F3'
                msg_fg = 'white'
                name_color = '#757575'
                name_text = "You"
            else:
                msg_bg = 'white'
                msg_fg = '#424242'
                name_color = '#2196F3'
                name_text = "Assistant"
            
            # Add name label
            name_label = tk.Label(bubble_frame, text=name_text,
                              font=('Segoe UI', 8),
                              fg=name_color, bg='#F5F5F5')
            name_label.pack(anchor='w' if not is_user else 'e', pady=(0, 2))
            
            # Create message bubble
            msg_bubble = tk.Label(bubble_frame, text=message,
                              wraplength=180,
                              justify=tk.LEFT,
                              bg=msg_bg, fg=msg_fg,
                              padx=12, pady=8,
                              font=('Segoe UI', 9))
            msg_bubble.pack(side=tk.TOP)
            
            # Add timestamp
            time_label = tk.Label(bubble_frame, text=timestamp,
                              font=('Segoe UI', 7),
                              fg='#9E9E9E', bg='#F5F5F5')
            time_label.pack(side=tk.BOTTOM, anchor='e' if is_user else 'w', pady=(2, 0))
            
            # Round corners using canvas
            msg_bubble.configure(relief=tk.FLAT)
            
            # Add typing indicator for bot messages
            if not is_user:
                def show_typing():
                    typing_frame = tk.Frame(message_frame, bg='#F5F5F5')
                    typing_frame.pack(fill=tk.X, padx=10, pady=2)
                    
                    # Create typing container with avatar
                    typing_container = tk.Frame(typing_frame, bg='#F5F5F5')
                    typing_container.pack(anchor='w')
                    
                    # Add small bot avatar
                    small_avatar = tk.Canvas(typing_container, width=28, height=28,
                                        bg='#F5F5F5', highlightthickness=0)
                    small_avatar.pack(side=tk.LEFT, padx=(0, 8))
                    
                    # Draw avatar
                    small_avatar.create_oval(2, 2, 26, 26,
                                        fill='#2196F3', outline='#2196F3')
                    
                    # Typing dots container
                    dots_frame = tk.Frame(typing_container, bg='white', padx=12, pady=8)
                    dots_frame.pack(side=tk.LEFT)
                    
                    # Create dots
                    dots = []
                    for i in range(3):
                        dot = tk.Canvas(dots_frame, width=6, height=6,
                                    bg='white', highlightthickness=0)
                        dot.pack(side=tk.LEFT, padx=2)
                        dot.create_oval(0, 0, 6, 6, fill='#90CAF9', outline='#90CAF9')
                        dots.append(dot)
                    
                    # Animate dots
                    def animate_dots():
                        for i, dot in enumerate(dots):
                            chat_window.after(i * 200, lambda d=dot: d.itemconfig(1, fill='#2196F3', outline='#2196F3'))
                            chat_window.after(i * 200 + 400, lambda d=dot: d.itemconfig(1, fill='#90CAF9', outline='#90CAF9'))
                    
                    animate_dots()
                    chat_window.after(1000, typing_frame.destroy)
                
                chat_window.after(200, show_typing)
            
            # Auto-scroll to bottom
            chat_canvas.update_idletasks()
            chat_canvas.yview_moveto(1.0)
        
        # Add welcome message
        add_message("Hello! How can I help you today?", False)
        
        def send_message(event=None):
            message = text_input.get("1.0", tk.END).strip()
            if message:
                add_message(message, True)
                text_input.delete("1.0", tk.END)
                
                # Get chatbot response
                chatbot = ChatBot()
                response = chatbot.get_response(message)
                chat_window.after(500, lambda: add_message(response, False))
        
        # Bind send button and Enter key
        send_button.configure(command=send_message)
        text_input.bind("<Return>", lambda e: send_message() if not e.state & 1 else None)
        
        # Add hover effects to send button
        def on_enter(e):
            send_button.configure(bg='#1976D2')
        
        def on_leave(e):
            send_button.configure(bg='#2196F3')
        
        send_button.bind("<Enter>", on_enter)
        send_button.bind("<Leave>", on_leave)
        
        # Add fade-in effect
        chat_window.attributes('-alpha', 0.0)
        for i in range(11):
            chat_window.attributes('-alpha', i/10)
            chat_window.update()
            chat_window.after(20)
        
        # Focus text input
        text_input.focus_set()

    def add_recent_file(self, file_path):
        """Add a file to recent files list"""
        if file_path not in self.recent_files:
            self.recent_files.insert(0, file_path)
            # Keep only the last 10 recent files
            self.recent_files = self.recent_files[:10]

    def start_update_check(self):
        """Start periodic update checks"""
        def check_updates():
            while True:
                self.update_manager.check_for_updates()
                time.sleep(self.update_manager.update_check_interval)
                
        update_thread = threading.Thread(target=check_updates, daemon=True)
        update_thread.start()

class ChatBot:
    def __init__(self):
        self.conversation_history = []
        self.greetings = ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening']
        self.farewells = ['bye', 'goodbye', 'see you', 'farewell', 'exit', 'quit']
        self.thanks = ['thank you', 'thanks', 'appreciate it', 'thank']
        self.contact_keywords = ['contact', 'representative', 'support', 'help desk', 'customer service', 'phone', 'email support']
        self.feature_keywords = {
            'bubble': ['bubble', 'balloons', 'circles'],
            'stamp': ['stamp', 'stamps', 'marking'],
            'template': ['template', 'templates', 'save template', 'load template'],
            'email': ['email', 'send', 'mail'],
            'drawing': ['draw', 'drawing', 'canvas'],
            'color': ['color', 'colours', 'change color'],
            'undo': ['undo', 'revert', 'go back'],
            'save': ['save', 'export', 'download'],
            'print': ['print', 'printing'],
            'rotate': ['rotate', 'rotation', 'turn'],
            'contact': ['contact', 'support', 'representative', 'help desk']
        }

    def get_response(self, user_input):
        # Convert input to lowercase and store in history
        user_input = user_input.lower().strip()
        self.conversation_history.append(("user", user_input))
        
        # Generate response
        response = self._generate_response(user_input)
        
        # Store response in history
        self.conversation_history.append(("bot", response))
        
        # Keep only last 20 conversations
        if len(self.conversation_history) > 20:
            self.conversation_history = self.conversation_history[-20:]
            
        return response

    def _generate_response(self, user_input):
        # Check for contact-related queries first
        if any(keyword in user_input for keyword in self.contact_keywords):
            return self._get_contact_info()

        # Check for greetings
        if any(greeting in user_input for greeting in self.greetings):
            return "Hello! How can I help you with the Balloon Drawing Software today?"
            
        # Check for farewells
        if any(farewell in user_input for farewell in self.farewells):
            return "Goodbye! Feel free to come back if you need any more help!"
            
        # Check for thanks
        if any(thank in user_input for thank in self.thanks):
            return "You're welcome! Is there anything else you'd like to know?"
            
        # Check for help request
        if 'help' in user_input:
            return ("I can help you with various features like:\n"
                   "- Drawing bubbles and stamps\n"
                   "- Using templates\n"
                   "- Sending emails\n"
                   "- Saving and printing drawings\n"
                   "Just ask me about any specific feature!")
            
        # Check for feature-specific questions
        for feature, keywords in self.feature_keywords.items():
            if any(keyword in user_input for keyword in keywords):
                return self._get_feature_help(feature)
                
        # Check for common questions
        if "how to" in user_input:
            for feature, keywords in self.feature_keywords.items():
                if any(keyword in user_input for keyword in keywords):
                    return self._get_feature_help(feature)
                    
        # Handle questions about previous responses
        if any(word in user_input for word in ['what', 'explain', 'clarify']) and len(self.conversation_history) > 2:
            last_bot_response = self.conversation_history[-2][1]
            return f"Let me clarify my previous response: {last_bot_response}\nWhat specific part would you like me to explain further?"

        # Default response with contact information
        return ("I apologize, but I'm not sure how to help with that specific query. "
               "For better assistance, please contact our support team:\n\n"
               f"{self._get_contact_info()}\n\n"
               "In the meantime, you can ask me about:\n"
               "- Drawing bubbles and stamps\n"
               "- Using templates\n"
               "- Saving and printing\n"
               "- Other basic features")

    def _get_contact_info(self):
        return ("You can reach our support team through:\n"
                "1. Email: \n"
                "2. Phone: \n"
                "3. Live Chat: Click the 'Chat with Support' button\n"
                "4. Support Hours: Monday-Friday, 9 AM - 6 PM EST\n\n"
                "Our representatives will be happy to assist you!")

    def _get_feature_help(self, feature):
        help_texts = {
            'bubble': ("To work with bubbles:\n"
                      "1. Click the bubble tool in the toolbar\n"
                      "2. Choose the bubble size and color\n"
                      "3. Click and drag on the canvas to draw bubbles\n"
                      "You can also edit existing bubbles by double-clicking them."),
                      
            'stamp': ("To use stamps:\n"
                     "1. Select a stamp type from the stamp menu\n"
                     "2. Choose the stamp size and color\n"
                     "3. Click on the canvas to place stamps\n"
                     "You can rotate stamps by using the rotation handle."),
                     
            'template': ("Templates help you save and reuse your designs:\n"
                        "1. Create your design\n"
                        "2. Click 'Save as Template'\n"
                        "3. Give your template a name\n"
                        "To use a template, click 'Load Template' and select one from your saved templates."),
                        
            'email': ("To share your drawing via email:\n"
                     "1. Click the 'Send Email' button\n"
                     "2. Enter recipient email addresses\n"
                     "3. Add a subject and message\n"
                     "4. Click 'Send' to share your drawing"),
                     
            'drawing': ("Basic drawing tips:\n"
                       "- Use left click to draw\n"
                       "- Right click to select items\n"
                       "- Use Ctrl+Z to undo\n"
                       "- Use the grid feature for alignment\n"
                       "Would you like more specific drawing tips?"),
                       
            'color': ("To change colors:\n"
                     "1. Click the color picker button\n"
                     "2. Choose a color from the palette\n"
                     "3. Or enter a custom color code\n"
                     "You can set different colors for bubbles and stamps."),
                     
            'undo': ("To undo actions:\n"
                    "- Press Ctrl+Z\n"
                    "- Or click the Undo button in the toolbar\n"
                    "You can undo multiple steps!"),
                    
            'save': ("To save your work:\n"
                    "1. Click 'Save' or press Ctrl+S\n"
                    "2. Choose a location and format\n"
                    "3. Your drawing can be saved as image or PDF"),
                    
            'print': ("To print your drawing:\n"
                     "1. Click the Print button or press Ctrl+P\n"
                     "2. Choose your printer and settings\n"
                     "3. Preview the print layout\n"
                     "4. Click Print to start printing"),
                     
            'rotate': ("To rotate items:\n"
                      "1. Select the item you want to rotate\n"
                      "2. Use the rotation handle that appears\n"
                      "3. Or use the rotation dialog for precise angles\n"
                      "You can also use Ctrl+R for quick rotation."),
                      
            'contact': ("Our support team is here to help!\n"
                       "1. Email: support@balloondrawing.com\n"
                       "2. Phone: 1-800-BALLOON (1-800-225-5666)\n"
                       "3. Live Chat: Available on our website\n"
                       "4. Hours: Monday-Friday, 9 AM - 6 PM EST")
        }
        
        return help_texts.get(feature, "I'm not sure about that feature. " + self._get_contact_info())

# Run the application
root = tk.Tk()
app = BubbleAndStampApp(root)
root.mainloop()
